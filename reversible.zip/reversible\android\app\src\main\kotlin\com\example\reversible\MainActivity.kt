package com.example.reversible

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
