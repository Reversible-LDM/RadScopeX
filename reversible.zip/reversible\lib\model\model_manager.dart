import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'tflite_runner.dart';

/// TFLite 모델 파일 관리.
/// - assets/models/에 번들된 기본 모델
/// - 서버에서 다운로드한 모델은 앱 데이터 디렉토리에 저장
class ModelManager {
  final TfliteRunner runner = TfliteRunner();

  static const bundledModels = <String>[];

  /// 로컬에 저장된 모델 목록 반환
  Future<List<String>> listLocalModels() async {
    final dir = await _modelDir();
    if (!await dir.exists()) return [];

    return dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.tflite'))
        .map((f) => f.path.split(Platform.pathSeparator).last.replaceAll('.tflite', ''))
        .toList();
  }

  /// 모델 로드 (로컬 우선, 없으면 번들)
  Future<void> loadModel(String modelName) async {
    // 1) 로컬 저장소 확인
    final localPath = await _localModelPath(modelName);
    if (await File(localPath).exists()) {
      await runner.loadFromFile(localPath);
      return;
    }

    throw FileSystemException('모델을 찾을 수 없습니다: $modelName');
  }

  /// 서버에서 받은 바이트를 로컬에 저장
  Future<String> saveModel(String modelName, List<int> bytes) async {
    final path = await _localModelPath(modelName);
    final file = File(path);
    await file.parent.create(recursive: true);
    await file.writeAsBytes(bytes);
    return path;
  }

  /// 로컬에 저장된 모델 삭제
  Future<void> deleteModel(String modelName) async {
    final path = await _localModelPath(modelName);
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  /// 사용 가능한 모든 모델 이름 (번들 + 로컬)
  Future<List<String>> listAllModels() async {
    final local = await listLocalModels();
    final all = <String>{...bundledModels, ...local};
    return all.toList()..sort();
  }

  Future<Directory> _modelDir() async {
    final base = await getApplicationSupportDirectory();
    return Directory('${base.path}/models');
  }

  Future<String> _localModelPath(String modelName) async {
    final dir = await _modelDir();
    return '${dir.path}/$modelName.tflite';
  }

  void dispose() {
    runner.dispose();
  }
}
