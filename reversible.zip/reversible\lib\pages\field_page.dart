import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import '../providers/field_provider.dart';
import '../core/matrix2d.dart';
import '../model/model_manager.dart';
import '../model/model_utils.dart';
import '../model/terrain_manager.dart';
import '../models/drone_measurement.dart';
import '../simulation/outdoor_simulation.dart';
import '../widgets/plotly_webview.dart';
import '../widgets/plotly_chart_builder.dart';
import '../services/training_service.dart';
import '../services/field_service.dart';
import '../providers/server_provider.dart';

class FieldPage extends ConsumerStatefulWidget {
  const FieldPage({super.key});

  @override
  ConsumerState<FieldPage> createState() => _FieldPageState();
}

class _FieldPageState extends ConsumerState<FieldPage> {
  late FieldService _fieldService;
  final _modelManager = ModelManager();
  final _terrainManager = TerrainManager();
  final _modelNameCtrl = TextEditingController();

  bool _loading = false;
  String _status = '';

  // 온라인
  List<String> _cities = [];
  String? _selectedCity;
  String? _selectedShpDir;
  String? _csvPath;
  String? _csvFileName;

  // 지형 지리 정보 (오프라인 GPS→픽셀 변환용)
  double? _centerLat;
  double? _centerLon;
  double _terrainExtentXm = 100.0;
  double _terrainExtentYm = 100.0;


  // 오프라인
  List<String> _localTerrains = [];

  List<String> _localModels = [];
  String? _selectedModel;
  String? _offlineCsvPath;
  String? _offlineCsvFileName;
  List<String> _offlineCsvHeaders = [];
  String _offlineMeasurementCol = 'CPS';
  String _offlineAltitudeCol = 'GPS_Altitude';

  // CSV 컬럼
  List<String> _csvHeaders = [];
  String _measurementCol = 'CPS';
  String _altitudeCol = 'GPS_Altitude';

  // 학습 파라미터
  int _numSamples = 100;
  int _epochs = 20;

  // 결과
  List<List<double>> _dronePath = [];
  List<double> _droneValues = [];
  DroneMeasurement? _measurement;
  double _droneAltitude = 30.0;
  Matrix2D? _idwMap;
  Matrix2D? _aiPrediction;

  // 단계 제어
  bool _terrainGenerated = false;
  bool _fieldAnalyzed = false;
  bool _modelTrained = false;

  static String _sanitizeName(String name) {
    return name
        .replaceAll(RegExp(r'[^\w\-]'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .replaceAll(RegExp(r'^_|_$'), '');
  }

  static const _fieldCamera = {
    'eye': {'x': 0, 'y': 0, 'z': 1.5},
    'up': {'x': 0, 'y': 1, 'z': 0},
    'center': {'x': 0, 'y': 0, 'z': 0},
  };

  @override
  void initState() {
    super.initState();
    final serverUrl = ref.read(serverUrlProvider);
    _fieldService = FieldService(serverUrl);
    _init();
  }

  @override
  void dispose() {
    _modelNameCtrl.dispose();
    _modelManager.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    final serverUrl = ref.read(serverUrlProvider);
    _fieldService = FieldService(serverUrl);

    final online = await TrainingService(serverUrl: serverUrl).checkConnection();
    if (online) _loadCities();

    final terrains = await _terrainManager.listAll();
    final models = await _modelManager.listAllModels();
    setState(() {
      _localTerrains = terrains;
      _localModels = models;
    });
  }

  Future<void> _loadCities() async {
    try {
      final serverUrl = ref.read(serverUrlProvider);
      final res = await http.get(
        Uri.parse('$serverUrl/api/field_list_cities'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        setState(() => _cities = List<String>.from(data['cities'] ?? []));
      }
    } catch (_) {}
  }

  Future<void> _loadShapefiles(String city) async {
    setState(() => _selectedShpDir = null);
    try {
      final serverUrl = ref.read(serverUrlProvider);
      final res = await http.get(
        Uri.parse('$serverUrl/api/field_list_shapefiles?city=$city'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final list = List<Map<String, dynamic>>.from(data['shapefiles'] ?? []);
        if (list.isNotEmpty) setState(() => _selectedShpDir = list.first['path'] as String);
      }
    } catch (_) {}
  }

  Future<void> _pickCsv({bool offline = false}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    final name = result.files.single.name;

    if (offline) {
      setState(() { _offlineCsvPath = path; _offlineCsvFileName = name; });
      await _fetchColumnsOffline(path);
    } else {
      setState(() {
        _csvPath = path;
        _csvFileName = name;
        _terrainGenerated = false;
        _fieldAnalyzed = false;
        _modelTrained = false;
        if (_modelNameCtrl.text.isEmpty) {
          final base = name.replaceAll('.csv', '');
          _modelNameCtrl.text = _sanitizeName(base);
        }
      });
      // 서버에서 컬럼 목록 조회
      await _fetchColumns(path);
    }
  }

  Future<void> _fetchColumns(String csvPath) async {
    try {
      final data = await _fieldService.getColumns(csvPath);
      final cols = List<String>.from(data['columns'] ?? []);
      final valueCandidates = List<String>.from(data['value_candidates'] ?? []);
      final altCandidates = List<String>.from(data['alt_candidates'] ?? []);
      setState(() {
        _csvHeaders = cols;
        if (valueCandidates.isNotEmpty) _measurementCol = valueCandidates.first;
        if (altCandidates.isNotEmpty) _altitudeCol = altCandidates.first;
      });
    } catch (_) {}
  }

  Future<void> _fetchColumnsOffline(String csvPath) async {
    try {
      final content = await File(csvPath).readAsString();
      final rows = const CsvToListConverter().convert(content);
      if (rows.isEmpty) return;
      final headers = rows[0].map((h) => h.toString().trim()).toList();
      const valuePriority = ['CPS', 'Doserate', 'CPS(Neutron)'];
      const altPriority = ['GPS_Altitude', 'Altimeter_Altitude'];
      setState(() {
        _offlineCsvHeaders = headers;
        final v = valuePriority.firstWhere((c) => headers.contains(c), orElse: () => _offlineMeasurementCol);
        final a = altPriority.firstWhere((c) => headers.contains(c), orElse: () => _offlineAltitudeCol);
        _offlineMeasurementCol = v;
        _offlineAltitudeCol = a;
      });
    } catch (_) {}
  }

  // GPS → 픽셀 (지형 중심 기반 역변환)
  /// GPS → 픽셀 변환. 지형 밖이면 null 반환.
  (int, int)? _gpsToPixel(double lat, double lon, Matrix2D terrain) {
    const metersPerDegLat = 111000.0;
    final metersPerDegLon = 111000.0 * cos(_centerLat! * pi / 180);
    final dxM = (lon - _centerLon!) * metersPerDegLon;
    final dyM = (lat - _centerLat!) * metersPerDegLat;
    final px = ((dxM + _terrainExtentXm / 2) / _terrainExtentXm * (terrain.cols - 1)).round();
    final py = (((_terrainExtentYm / 2) - dyM) / _terrainExtentYm * (terrain.rows - 1)).round();
    if (px < 0 || px >= terrain.cols || py < 0 || py >= terrain.rows) return null;
    return (px, py);
  }

  // Convex hull (Andrew's monotone chain)
  List<(double, double)> _convexHull(List<(double, double)> pts) {
    if (pts.length < 3) return pts;
    final sorted = List.of(pts)..sort((a, b) => a.$1 != b.$1 ? a.$1.compareTo(b.$1) : a.$2.compareTo(b.$2));
    double cross((double, double) o, (double, double) a, (double, double) b) =>
        (a.$1 - o.$1) * (b.$2 - o.$2) - (a.$2 - o.$2) * (b.$1 - o.$1);
    final lower = <(double, double)>[];
    for (final p in sorted) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) { lower.removeLast(); }
      lower.add(p);
    }
    final upper = <(double, double)>[];
    for (final p in sorted.reversed) {
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) { upper.removeLast(); }
      upper.add(p);
    }
    lower.removeLast();
    upper.removeLast();
    return [...lower, ...upper];
  }

  bool _pointInPolygon(double px, double py, List<(double, double)> poly) {
    bool inside = false;
    for (int i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      final xi = poly[i].$1, yi = poly[i].$2;
      final xj = poly[j].$1, yj = poly[j].$2;
      if (((yi > py) != (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi)) inside = !inside;
    }
    return inside;
  }

  Matrix2D _applyConvexHullMask(Matrix2D idw, List<(double, double)> dronePixels) {
    if (dronePixels.length < 3) return idw;
    final hull = _convexHull(dronePixels);
    final result = idw.copy();
    for (int r = 0; r < idw.rows; r++) {
      for (int c = 0; c < idw.cols; c++) {
        if (!_pointInPolygon(c.toDouble(), r.toDouble(), hull)) result.set(r, c, double.nan);
      }
    }
    return result;
  }

  Future<void> _analyzeFieldOffline() async {
    if (_offlineCsvPath == null || _centerLat == null || _centerLon == null) return;
    final terrain = ref.read(fieldProvider).terrain;
    if (terrain == null) return;

    setState(() { _loading = true; _status = '오프라인 IDW 분석 중...'; });
    try {
      final content = await File(_offlineCsvPath!).readAsString();
      final rows = const CsvToListConverter().convert(content);
      if (rows.length < 2) throw Exception('데이터 없음');

      final headers = rows[0].map((h) => h.toString().trim()).toList();
      final latIdx = headers.indexOf('Latitude');
      final lonIdx = headers.indexOf('Longitude');
      final valIdx = headers.indexOf(_offlineMeasurementCol);
      final altIdx = headers.indexOf(_offlineAltitudeCol);

      if (latIdx < 0 || lonIdx < 0) throw Exception('Latitude/Longitude 컬럼 없음');
      if (valIdx < 0) throw Exception('$_offlineMeasurementCol 컬럼 없음');

      final path = <DronePoint>[];
      final values = <double>[];
      final pixelPts = <(double, double)>[];

      for (int i = 1; i < rows.length; i++) {
        final row = rows[i];
        final maxIdx = max(latIdx, max(lonIdx, valIdx));
        if (row.length <= maxIdx) continue;
        final lat = double.tryParse(row[latIdx].toString());
        final lon = double.tryParse(row[lonIdx].toString());
        final val = double.tryParse(row[valIdx].toString());
        if (lat == null || lon == null || val == null) continue;
        if (!lat.isFinite || !lon.isFinite || !val.isFinite) continue;
        final alt = (altIdx >= 0 && altIdx < row.length)
            ? (double.tryParse(row[altIdx].toString()) ?? 0.0)
            : 0.0;

        final pixel = _gpsToPixel(lat, lon, terrain);
        if (pixel == null) continue;
        final (px, py) = pixel;
        final terrainZ = terrain.get(py, px);
        final plotZ = alt.isFinite && alt > 0 ? alt : terrainZ + 30.0;

        path.add(DronePoint(px.toDouble(), py.toDouble(), plotZ));
        values.add(val);
        pixelPts.add((px.toDouble(), py.toDouble()));
      }

      if (path.isEmpty) throw Exception('유효한 데이터 없음');

      final measurement = DroneMeasurement(path: path, values: values);

      // 온라인 서버의 compute_coord_norm과 동일한 로직
      final dxM = _terrainExtentXm / (terrain.cols - 1).toDouble();
      final dyM = _terrainExtentYm / (terrain.rows - 1).toDouble();
      final xyUnit = max(dxM, dyM);
      final coordNorm = {'dx_m': dxM / xyUnit, 'dy_m': dyM / xyUnit, 'xy_unit': 1.0};

      final targetScale = values.isEmpty ? null : values.reduce((a, b) => a > b ? a : b);
      var idw = idwInterpolation(measurement, terrain.rows, terrain.cols,
          coordNorm: coordNorm, targetScale: targetScale,
          snapMeasurements: false, smoothSigma: 2.0);
      idw = _applyConvexHullMask(idw, pixelPts);

      // 드론 경로 — Plotly용 Y 반전
      final dronePath = path.map((p) => [p.x, (terrain.rows - 1 - p.y).toDouble(), p.z]).toList();

      setState(() {
        _dronePath = dronePath;
        _droneValues = values;
        _idwMap = idw;
        _measurement = measurement;
        _fieldAnalyzed = true;
        _status = '오프라인 분석 완료 (${path.length}개 포인트)';
      });
      _showSnack('오프라인 IDW 완료');
    } catch (e) {
      _showSnack('오류: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── 1단계: 지형 생성 ──────────────────────────────
  Future<void> _generateTerrain() async {
    if (_csvPath == null || _selectedShpDir == null) return;
    final modelName = _modelNameCtrl.text.trim();
    if (modelName.isEmpty) {
      _showSnack('모델 이름을 입력해주세요 (영문/숫자)');
      return;
    }

    setState(() { _loading = true; _status = '지형 생성 중...'; });
    try {
      final serverUrl = ref.read(serverUrlProvider);
      _fieldService = FieldService(serverUrl);

      final data = await _fieldService.generateTerrain(
        csvPath: _csvPath!,
        shpDir: _selectedShpDir!,
        modelName: modelName,
      );

      final zList = data['z_data'] as List;
      final rows = zList.length;
      final cols = (zList[0] as List).length;
      final terrain = Matrix2D(rows, cols);
      for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
          terrain.set(r, c, (zList[r][c] as num).toDouble());
        }
      }
      final extX = (data['extent_x_m'] as num).toDouble();
      final extY = (data['extent_y_m'] as num).toDouble();
      final tag = (data['terrain_model_tag'] as String?) ?? modelName;

      final centerLatlon = data['center_latlon'] as List?;
      final centerLat = centerLatlon != null ? (centerLatlon[0] as num).toDouble() : null;
      final centerLon = centerLatlon != null ? (centerLatlon[1] as num).toDouble() : null;
      final boundsRaw = data['bounds'] as Map<String, dynamic>?;
      final bounds = boundsRaw?.map((k, v) => MapEntry(k, (v as num).toDouble()));
      final crs = data['crs'] as String?;

      final terrainBase = (data['terrain_base_altitude_m'] as num?)?.toDouble() ?? 0.0;
      await _terrainManager.save(tag, terrain, extX, extY,
          centerLat: centerLat, centerLon: centerLon, bounds: bounds, crs: crs,
          terrainBaseAltitude: terrainBase);

      setState(() {
        _centerLat = centerLat;
        _centerLon = centerLon;
        _terrainExtentXm = extX;
        _terrainExtentYm = extY;
      });

      ref.read(fieldProvider.notifier).setResult(
        terrain: terrain,
        modelTag: tag,
        csvFileName: _csvFileName!,
      );

      setState(() { _terrainGenerated = true; _status = '지형 생성 완료. 이제 분석을 실행하세요.'; });
      _showSnack('지형 생성 완료: $tag');

      final terrains = await _terrainManager.listAll();
      setState(() => _localTerrains = terrains);
    } catch (e) {
      _showSnack('오류: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── 2단계: 필드 데이터 분석 (IDW + 드론 경로) ──────
  Future<void> _analyzeField() async {
    if (_csvPath == null) return;

    setState(() { _loading = true; _status = '필드 데이터 분석 중...'; });
    try {
      final data = await _fieldService.uploadFieldData(
        csvPath: _csvPath!,
        valueCol: _measurementCol,
        altCol: _altitudeCol,
      );

      final fieldState = ref.read(fieldProvider);
      final terrain = fieldState.terrain!;
      final rows = terrain.rows;

      // 드론 경로
      final pathList = data['drone_path'] as List;
      final dronePath = pathList.map((p) => [
        (p[0] as num).toDouble(),
        (rows - 1 - (p[1] as num)).toDouble(),
        (p[2] as num).toDouble(),
      ]).toList();
      final droneValues = List<double>.from(
          (data['values'] as List).map((v) => (v as num).toDouble()));

      // IDW 맵
      final idwList = data['idw_map'] as List;
      final idwRows = idwList.length;
      final idwCols = (idwList[0] as List).length;
      final idw = Matrix2D(idwRows, idwCols);
      for (int r = 0; r < idwRows; r++) {
        for (int c = 0; c < idwCols; c++) {
          final v = idwList[r][c];
          idw.set(r, c, v != null ? (v as num).toDouble() : double.nan);
        }
      }

      // DroneMeasurement 저장 (TFLite 예측용)
      final path = pathList.map((p) => DronePoint(
        (p[0] as num).toDouble(),
        (p[1] as num).toDouble(),
        (p[2] as num).toDouble(),
      )).toList();
      final avgAlt = path.isNotEmpty
          ? path.map((p) => p.z).reduce((a, b) => a + b) / path.length
          : 30.0;

      setState(() {
        _dronePath = dronePath;
        _droneValues = droneValues;
        _measurement = DroneMeasurement(path: path, values: droneValues);
        _droneAltitude = avgAlt;
        _idwMap = idw;
        _fieldAnalyzed = true;
        _status = '분석 완료. AI 학습을 실행할 수 있습니다.';
      });
      _showSnack('필드 분석 완료 (${pathList.length}개 포인트)');
    } catch (e) {
      _showSnack('오류: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── 3단계: AI 학습 ────────────────────────────────
  Future<void> _trainModel() async {
    setState(() { _loading = true; _status = 'AI 학습 시작 중...'; });
    try {
      final cleanTag = _sanitizeName(_modelNameCtrl.text.trim());

      // 비동기 학습 시작 → job_id 수신
      final jobId = await _fieldService.startTrainAsync(
        numSamples: _numSamples,
        epochs: _epochs,
        modelTag: cleanTag.isNotEmpty ? cleanTag : null,
      );

      // 5초마다 상태 폴링
      setState(() => _status = 'AI 학습 중... (시간이 걸릴 수 있습니다)');
      Map<String, dynamic> trainResult = {};
      while (true) {
        await Future.delayed(const Duration(seconds: 5));
        if (!mounted) return;
        final status = await _fieldService.getTrainStatus(jobId);
        if (status['status'] == 'done') {
          trainResult = status;
          break;
        } else if (status['status'] == 'error') {
          throw Exception(status['error'] ?? '학습 실패');
        } else if (status['status'] == 'not_found') {
          // job이 이미 소비됨 → 학습 완료됐을 가능성 높음, 알고 있는 이름으로 다운로드 시도
          trainResult = {'model_name': _modelNameCtrl.text.trim()};
          break;
        }
      }

      // TFLite 모델 다운로드
      final serverUrl = ref.read(serverUrlProvider);
      final rawName = (trainResult['model_name'] as String?)?.isNotEmpty == true
          ? trainResult['model_name'] as String
          : _modelNameCtrl.text.trim();
      final modelName = _sanitizeName(rawName);
      final trainingService = TrainingService(serverUrl: serverUrl);
      try {
        final bytes = await trainingService.downloadModel(modelName);
        await _modelManager.saveModel(modelName, bytes);
        final models = await _modelManager.listAllModels();
        setState(() { _localModels = models; });
        _showSnack('학습 완료 + 모델 저장됨: $modelName');
      } catch (_) {
        _showSnack('학습 완료 (모델 다운로드 실패)');
      }

      setState(() { _modelTrained = true; _status = '학습 완료. AI 예측을 실행할 수 있습니다.'; });
    } catch (e) {
      _showSnack('학습 실패: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── 4단계: AI 예측 ────────────────────────────────
  Future<void> _predict() async {
    setState(() { _loading = true; _status = 'AI 예측 중...'; });
    try {
      // 저장된 모델 선택 시 TFLite 오프라인 예측
      // 드론 픽셀 좌표 (Y플립 역변환)
      final terrain = ref.read(fieldProvider).terrain!;
      final pixelPts = _dronePath.map((p) => (p[0], (terrain.rows - 1 - p[1]))).toList();

      if (_selectedModel != null && _measurement != null) {
        await _modelManager.loadModel(_selectedModel!);
        final inputData = formatMeasurementsForModel(_measurement!, terrain, _droneAltitude);
        final (padH, padW) = computePaddedShapeForModel(terrain.rows, terrain.cols);
        final paddedInput = padInput4D(inputData, padH, padW);
        final prediction = _modelManager.runner.predict(paddedInput);
        var cropped = cropOutput(prediction, terrain.rows, terrain.cols);
        if (pixelPts.isNotEmpty) cropped = _applyConvexHullMask(cropped, pixelPts);
        setState(() { _aiPrediction = cropped; _status = 'AI 예측 완료 (TFLite)'; });
        _showSnack('AI 예측 완료 (TFLite)');
        return;
      }

      // 서버 예측
      final data = await _fieldService.predict();
      final predList = data['prediction'] as List;
      final rows = predList.length;
      final cols = (predList[0] as List).length;
      final pred = Matrix2D(rows, cols);
      for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
          final v = predList[r][c];
          pred.set(r, c, v != null ? (v as num).toDouble() : double.nan);
        }
      }
      setState(() { _aiPrediction = pred; _status = 'AI 예측 완료'; });
      _showSnack('AI 예측 완료');
    } catch (e) {
      _showSnack('예측 실패: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _runOffline() async {
    if (_selectedModel == null || _offlineCsvPath == null || _centerLat == null) return;
    final terrain = ref.read(fieldProvider).terrain;
    if (terrain == null) return;

    setState(() { _loading = true; _status = '오프라인 AI 예측 중...'; });
    try {
      // CSV 파싱 → measurement 빌드
      final content = await File(_offlineCsvPath!).readAsString();
      final rows = const CsvToListConverter().convert(content);
      if (rows.length < 2) throw Exception('데이터 없음');

      final headers = rows[0].map((h) => h.toString().trim()).toList();
      final latIdx = headers.indexOf('Latitude');
      final lonIdx = headers.indexOf('Longitude');
      final valIdx = headers.indexOf(_offlineMeasurementCol);
      final altIdx = headers.indexOf(_offlineAltitudeCol);
      if (latIdx < 0 || lonIdx < 0) throw Exception('Latitude/Longitude 컬럼 없음');
      if (valIdx < 0) throw Exception('$_offlineMeasurementCol 컬럼 없음');

      final cLat = _centerLat!;
      final cLon = _centerLon!;
      final extX = _terrainExtentXm;
      final extY = _terrainExtentYm;

      final path = <DronePoint>[];
      final values = <double>[];
      final pixelPts = <(double, double)>[];

      for (int i = 1; i < rows.length; i++) {
        final row = rows[i];
        final maxIdx = max(latIdx, max(lonIdx, valIdx));
        if (row.length <= maxIdx) continue;
        final lat = double.tryParse(row[latIdx].toString());
        final lon = double.tryParse(row[lonIdx].toString());
        final val = double.tryParse(row[valIdx].toString());
        if (lat == null || lon == null || val == null) continue;
        if (!lat.isFinite || !lon.isFinite || !val.isFinite) continue;
        final alt = (altIdx >= 0 && altIdx < row.length)
            ? (double.tryParse(row[altIdx].toString()) ?? 0.0) : 0.0;

        const metersPerDegLat = 111000.0;
        final metersPerDegLon = 111000.0 * cos(cLat * pi / 180);
        final dxM = (lon - cLon) * metersPerDegLon;
        final dyM = (lat - cLat) * metersPerDegLat;
        final px = ((dxM + extX / 2) / extX * (terrain.cols - 1)).round();
        final py = ((extY / 2 - dyM) / extY * (terrain.rows - 1)).round();
        if (px < 0 || px >= terrain.cols || py < 0 || py >= terrain.rows) continue;

        final terrainZ = terrain.get(py, px);
        final plotZ = alt.isFinite && alt > 0 ? alt : terrainZ + 30.0;
        path.add(DronePoint(px.toDouble(), py.toDouble(), plotZ));
        values.add(val);
        pixelPts.add((px.toDouble(), py.toDouble()));
      }

      if (path.isEmpty) throw Exception('유효한 데이터 없음');

      final measurement = DroneMeasurement(path: path, values: values);
      final dronePath = path.map((p) => [p.x, (terrain.rows - 1 - p.y).toDouble(), p.z]).toList();

      // TFLite AI 예측
      await _modelManager.loadModel(_selectedModel!);
      final inputData = formatMeasurementsForModel(measurement, terrain, _droneAltitude);
      final (padH, padW) = computePaddedShapeForModel(terrain.rows, terrain.cols);
      final paddedInput = padInput4D(inputData, padH, padW);
      var pred = cropOutput(_modelManager.runner.predict(paddedInput), terrain.rows, terrain.cols);
      if (pixelPts.isNotEmpty) pred = _applyConvexHullMask(pred, pixelPts);

      setState(() {
        _dronePath = dronePath;
        _droneValues = values;
        _measurement = measurement;
        _aiPrediction = pred;
        _centerLat = cLat;
        _centerLon = cLon;
        _terrainExtentXm = extX;
        _terrainExtentYm = extY;
        _fieldAnalyzed = true;
        _status = '오프라인 AI 예측 완료';
      });
      _showSnack('오프라인 AI 예측 완료');
    } catch (e) {
      _showSnack('오류: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadSavedTerrain(String tag) async {
    final info = await _terrainManager.load(tag);
    if (info == null || !mounted) return;

    ref.read(fieldProvider.notifier).setResult(
      terrain: info.terrain,
      modelTag: tag,
      csvFileName: '',
    );
    setState(() {
      _centerLat = info.centerLat;
      _centerLon = info.centerLon;
      _terrainExtentXm = info.extentX;
      _terrainExtentYm = info.extentY;
      _terrainGenerated = true;
      _fieldAnalyzed = false;
      _modelTrained = false;
      _dronePath = [];
      _droneValues = [];
      _idwMap = null;
      _aiPrediction = null;
      _measurement = null;
      _status = '지형 로드됨: $tag';
    });

    // 온라인 상태면 서버 세션에도 복원 (필드 분석 2~4단계 사용 가능하도록)
    final isOnline = ref.read(serverOnlineProvider).valueOrNull ?? false;
    if (isOnline) {
      try {
        final serverUrl = ref.read(serverUrlProvider);
        _fieldService = FieldService(serverUrl);
        await _fieldService.restoreTerrain(
          zData: info.terrain.toList(),
          extentXm: info.extentX,
          extentYm: info.extentY,
          modelTag: tag,
          bounds: info.bounds,
          crs: info.crs,
          terrainBaseAltitude: info.terrainBaseAltitude,
        );
        setState(() => _status = '지형 로드됨: $tag. 필드 분석 가능.');
      } catch (_) {
        setState(() => _status = '지형 로드됨: $tag (서버 복원 실패 — 온라인 분석 불가)');
      }
    }

    _showSnack('지형 로드됨: $tag');
  }

  Future<void> _deleteSavedTerrain(String tag) async {
    await _terrainManager.delete(tag);
    final terrains = await _terrainManager.listAll();
    setState(() => _localTerrains = terrains);
    _showSnack('삭제됨: $tag');
  }

  void _showSnack(String msg) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final fieldState = ref.watch(fieldProvider);
    final isOnline = ref.watch(serverOnlineProvider).valueOrNull ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('5. 필드 분석')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            isOnline ? _buildOnlineCard() : _buildOfflineCard(),

            const SizedBox(height: 16),
            _buildTerrainManagerCard(),
            const SizedBox(height: 16),
            _buildModelManagerCard(),

            if (_status.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(_status, style: TextStyle(
                color: Theme.of(context).colorScheme.secondary,
                fontSize: 12,
              )),
            ],

            // 차트 3개 가로 배치
            if (fieldState.terrain != null) ...[
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: _buildResultCard(
                      title: fieldState.modelTag ?? '지형',
                      spec: _dronePath.isNotEmpty
                          ? PlotlyChartBuilder.surfaceWithDronePath(
                              fieldState.terrain!, _dronePath, _droneValues,
                              camera: _fieldCamera,
                            )
                          : PlotlyChartBuilder.terrainWhite(
                              fieldState.terrain!,
                              camera: _fieldCamera,
                            ),
                    ),
                  ),
                  if (_idwMap != null) ...[
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildResultCard(
                        title: 'IDW 보간',
                        spec: PlotlyChartBuilder.terrainWithContamination(
                          fieldState.terrain!,
                          _idwMap!,
                          camera: _fieldCamera,
                        ),
                      ),
                    ),
                  ],
                  if (_aiPrediction != null) ...[
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildResultCard(
                        title: 'AI 예측',
                        spec: PlotlyChartBuilder.terrainWithContamination(
                          fieldState.terrain!,
                          _aiPrediction!,
                          camera: _fieldCamera,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTerrainManagerCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('저장된 지형',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (_localTerrains.isEmpty)
              const Text('저장된 지형 없음',
                  style: TextStyle(color: Colors.grey))
            else
              ..._localTerrains.map((tag) {
                final isLoaded =
                    ref.read(fieldProvider).modelTag == tag && _terrainGenerated;
                return ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.terrain, size: 18,
                      color: isLoaded ? Colors.blueAccent : Colors.grey),
                  title: Text(tag, style: const TextStyle(fontSize: 13)),
                  subtitle: isLoaded
                      ? const Text('현재 로드됨',
                          style: TextStyle(fontSize: 11, color: Colors.blueAccent))
                      : null,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(
                          isLoaded ? Icons.check_circle : Icons.download_done,
                          size: 18,
                          color: isLoaded ? Colors.blueAccent : Colors.green,
                        ),
                        tooltip: '불러오기',
                        onPressed: isLoaded ? null : () => _loadSavedTerrain(tag),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            size: 18, color: Colors.redAccent),
                        tooltip: '삭제',
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text('지형 삭제'),
                              content: Text('\'$tag\' 를 삭제하시겠습니까?'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('취소')),
                                TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('삭제', style: TextStyle(color: Colors.red))),
                              ],
                            ),
                          );
                          if (ok == true) _deleteSavedTerrain(tag);
                        },
                      ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildModelManagerCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('저장된 모델',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (_localModels.isEmpty)
              const Text('저장된 모델 없음 (3. AI 학습 후 자동 저장됨)',
                  style: TextStyle(color: Colors.grey))
            else
              ..._localModels.map((m) {
                final isSelected = _selectedModel == m;
                return ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.psychology, size: 18,
                      color: isSelected ? Colors.blueAccent : Colors.green),
                  title: Text(m, style: const TextStyle(fontSize: 13)),
                  subtitle: isSelected
                      ? const Text('선택됨',
                          style: TextStyle(fontSize: 11, color: Colors.blueAccent))
                      : null,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(
                          isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                          size: 18,
                          color: isSelected ? Colors.blueAccent : Colors.grey,
                        ),
                        tooltip: '선택',
                        onPressed: () => setState(() => _selectedModel = m),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            size: 18, color: Colors.redAccent),
                        tooltip: '삭제',
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text('모델 삭제'),
                              content: Text('\'$m\' 를 삭제하시겠습니까?'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('취소')),
                                TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('삭제', style: TextStyle(color: Colors.red))),
                              ],
                            ),
                          );
                          if (ok != true) return;
                          await _modelManager.deleteModel(m);
                          final models = await _modelManager.listAllModels();
                          setState(() {
                            _localModels = models;
                            if (_selectedModel == m) _selectedModel = null;
                          });
                        },
                      ),
                    ],
                  ),
                  onTap: () => setState(() => _selectedModel = m),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard({required String title, required Map<String, dynamic> spec}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            PlotlyWebView(height: 380, chartSpec: spec),
          ],
        ),
      ),
    );
  }

  Widget _buildOnlineCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 지역 선택
            const Text('지역 선택', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            InputDecorator(
              decoration: const InputDecoration(
                labelText: '도시', border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              ),
              child: DropdownButton<String>(
                value: _selectedCity, isExpanded: true, underline: const SizedBox(),
                hint: const Text('도시 선택'),
                items: _cities.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _selectedCity = v);
                  _loadShapefiles(v);
                },
              ),
            ),

            const SizedBox(height: 16),
            // 드론 CSV
            const Text('드론 CSV', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [
              FilledButton.icon(
                onPressed: _pickCsv,
                icon: const Icon(Icons.file_open),
                label: const Text('CSV 선택'),
              ),
              const SizedBox(width: 12),
              if (_csvFileName != null)
                Expanded(child: Text(_csvFileName!, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.grey))),
            ]),

            if (_csvHeaders.isNotEmpty) ...[
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _colDropdown('측정값 컬럼', _measurementCol, _csvHeaders,
                    (v) => setState(() => _measurementCol = v!))),
                const SizedBox(width: 8),
                Expanded(child: _colDropdown('고도 컬럼', _altitudeCol, _csvHeaders,
                    (v) => setState(() => _altitudeCol = v!))),
              ]),
            ],

            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _intField('샘플 수', _numSamples,
                  (v) { if (v > 0) setState(() => _numSamples = v); })),
              const SizedBox(width: 8),
              Expanded(child: _intField('Epochs', _epochs,
                  (v) { if (v > 0) setState(() => _epochs = v); })),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _modelNameCtrl,
              decoration: const InputDecoration(
                labelText: '모델 이름 (영문/숫자)', hintText: 'busan_field_01',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
            ),

            const SizedBox(height: 16),
            // 단계별 버튼
            Wrap(
              spacing: 8, runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: (_loading || _csvPath == null || _selectedShpDir == null)
                      ? null : _generateTerrain,
                  icon: _loading && !_terrainGenerated
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.terrain),
                  label: const Text('1. 지형 생성'),
                ),
                FilledButton.icon(
                  onPressed: (_loading || !_terrainGenerated || _csvPath == null)
                      ? null : _analyzeField,
                  icon: _loading && _terrainGenerated && !_fieldAnalyzed
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.analytics),
                  label: const Text('2. 필드 분석'),
                ),
                FilledButton.icon(
                  onPressed: (_loading || !_fieldAnalyzed) ? null : _trainModel,
                  icon: _loading && _fieldAnalyzed && !_modelTrained
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.model_training),
                  label: const Text('3. AI 학습'),
                ),
                FilledButton.icon(
                  onPressed: (_loading || (!_modelTrained && (_selectedModel == null || !_fieldAnalyzed))) ? null : _predict,
                  icon: _loading && _modelTrained
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.psychology),
                  label: const Text('4. AI 예측'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOfflineCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('드론 CSV', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [
              FilledButton.icon(
                onPressed: () => _pickCsv(offline: true),
                icon: const Icon(Icons.file_open),
                label: const Text('CSV 선택'),
              ),
              const SizedBox(width: 12),
              if (_offlineCsvFileName != null)
                Expanded(child: Text(_offlineCsvFileName!, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.grey))),
            ]),

            if (_offlineCsvHeaders.isNotEmpty) ...[
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _colDropdown('측정값 컬럼', _offlineMeasurementCol, _offlineCsvHeaders,
                    (v) => setState(() => _offlineMeasurementCol = v!))),
                const SizedBox(width: 8),
                Expanded(child: _colDropdown('고도 컬럼', _offlineAltitudeCol, _offlineCsvHeaders,
                    (v) => setState(() => _offlineAltitudeCol = v!))),
              ]),
            ],

            const SizedBox(height: 16),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(
                onPressed: (_loading || !_terrainGenerated || _offlineCsvPath == null || _centerLat == null)
                    ? null : _analyzeFieldOffline,
                icon: _loading
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.analytics),
                label: const Text('오프라인 IDW'),
              ),
              if (_selectedModel != null)
                FilledButton.icon(
                  onPressed: (_loading || !_terrainGenerated || _selectedModel == null
                      || _offlineCsvPath == null) ? null : _runOffline,
                  icon: const Icon(Icons.psychology),
                  label: const Text('AI 예측 (TFLite)'),
                ),
            ]),
            if (_centerLat == null && _terrainGenerated)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('이 지형은 좌표 정보가 없습니다.\n온라인에서 재생성하면 오프라인 IDW가 가능합니다.',
                    style: TextStyle(color: Colors.orange, fontSize: 12)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _colDropdown(String label, String value, List<String> headers, ValueChanged<String?> onChanged) {
    final items = headers.contains(value) ? headers : [value, ...headers];
    return InputDecorator(
      decoration: InputDecoration(
        labelText: label, border: const OutlineInputBorder(),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      ),
      child: DropdownButton<String>(
        value: value, isExpanded: true, underline: const SizedBox(),
        items: items.map((h) => DropdownMenuItem(
          value: h, child: Text(h, overflow: TextOverflow.ellipsis),
        )).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _intField(String label, int value, void Function(int) onChanged) {
    return TextField(
      decoration: InputDecoration(
        labelText: label, border: const OutlineInputBorder(),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      keyboardType: TextInputType.number,
      controller: TextEditingController(text: '$value'),
      onChanged: (v) { final n = int.tryParse(v); if (n != null) onChanged(n); },
    );
  }
}
