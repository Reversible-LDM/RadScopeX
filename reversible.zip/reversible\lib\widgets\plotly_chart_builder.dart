import '../core/matrix2d.dart';

class PlotlyChartBuilder {
  static List<List<double>> _flipY(Matrix2D terrain) =>
      terrain.toList().reversed.toList();

  // NaN → null 변환 (Plotly에서 해당 셀 투명 처리)
  static List<List<dynamic>> _flipYSurface(Matrix2D m) =>
      m.toList().reversed.map(
        (row) => row.map<dynamic>((v) => v.isNaN ? null : v).toList(),
      ).toList();

  // Matrix2D 0~1 정규화 후 flipY + NaN→null
  static List<List<dynamic>> _normalizeFlipY(Matrix2D m) {
    final min = m.minValue();
    final max = m.maxValue();
    final range = (max - min) > 0 ? (max - min) : 1.0;
    return m.toList().reversed.map(
      (row) => row.map<dynamic>((v) => v.isNaN ? null : (v - min) / range).toList(),
    ).toList();
  }

  // List<double> 0~1 정규화
  static List<double> _normalizeList(List<double> values) {
    if (values.isEmpty) return values;
    final min = values.reduce((a, b) => a < b ? a : b);
    final max = values.reduce((a, b) => a > b ? a : b);
    final range = (max - min) > 0 ? (max - min) : 1.0;
    return values.map((v) => (v - min) / range).toList();
  }

  static Map<String, dynamic> surface3D(
    Matrix2D zData, {
    String title = '',
    String colorscale = 'Viridis',
    bool showScale = true,
    double? zmin,
    double? zmax,
  }) {
    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(zData),
          'surfacecolor': _normalizeFlipY(zData),
          'colorscale': colorscale,
          'showscale': showScale,
          'cmin': 0,
          'cmax': 1,
        },
      ],
      'layout': _surfaceLayout(title, zData),
    };
  }

  static Map<String, dynamic> surfaceWithDronePath(
    Matrix2D terrain,
    List<List<double>> dronePath,
    List<double> values, {
    String title = '',
    Map<String, dynamic>? camera,
  }) {
    final minVal = values.isEmpty ? 0.0 : values.reduce((a, b) => a < b ? a : b);
    final maxVal = values.isEmpty ? 1.0 : values.reduce((a, b) => a > b ? a : b);

    final zeros = List.generate(
      terrain.rows,
      (_) => List<double>.filled(terrain.cols, 0.0),
    );

    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(terrain),
          'surfacecolor': zeros,
          'colorscale': const [
            [0, '#f2f2f2'],
            [1, '#f2f2f2'],
          ],
          'cmin': 0,
          'cmax': 1,
          'showscale': false,
        },
        {
          'type': 'scatter3d',
          'mode': 'markers',
          'x': dronePath.map((p) => p[0]).toList(),
          'y': dronePath.map((p) => p[1]).toList(),
          'z': dronePath.map((p) => p[2]).toList(),
          'marker': {
            'size': 4,
            'color': _normalizeList(values),
            'colorscale': 'Reds',
            'cmin': 0,
            'cmax': 1,
            'showscale': true,
            'colorbar': {'title': 'CPS'},
          },
        },
      ],
      'layout': _surfaceLayout(title, terrain, camera: camera, orthographic: true),
    };
  }

  static Map<String, dynamic> dualSurface(
    Matrix2D surface1,
    Matrix2D surface2, {
    String title1 = 'Prediction',
    String title2 = 'Ground Truth',
    String colorscale = 'Hot',
  }) {
    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(surface1),
          'colorscale': colorscale,
          'showscale': true,
          'name': title1,
          'scene': 'scene',
        },
        {
          'type': 'surface',
          'z': _flipY(surface2),
          'colorscale': colorscale,
          'showscale': false,
          'name': title2,
          'scene': 'scene2',
        },
      ],
      'layout': {
        ..._baseLayout(''),
        'grid': {'rows': 1, 'columns': 2, 'pattern': 'independent'},
        'scene': {
          ..._sceneLayout(surface1),
          'domain': {'row': 0, 'column': 0},
        },
        'scene2': {
          ..._sceneLayout(surface2),
          'domain': {'row': 0, 'column': 1},
        },
        'annotations': [
          {
            'text': title1,
            'showarrow': false,
            'x': 0.2,
            'y': 1.05,
            'xref': 'paper',
            'yref': 'paper',
            'font': {'color': '#fff'},
          },
          {
            'text': title2,
            'showarrow': false,
            'x': 0.8,
            'y': 1.05,
            'xref': 'paper',
            'yref': 'paper',
            'font': {'color': '#fff'},
          },
        ],
      },
    };
  }

  static Map<String, dynamic> terrainWhite(
    Matrix2D terrain, {
    String title = 'Terrain',
    Map<String, dynamic>? camera,
  }) {
    final zeros = List.generate(
      terrain.rows,
      (_) => List<double>.filled(terrain.cols, 0.0),
    );

    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(terrain),
          'surfacecolor': zeros,
          'colorscale': const [
            [0, '#f2f2f2'],
            [1, '#f2f2f2'],
          ],
          'cmin': 0,
          'cmax': 1,
          'showscale': false,
        },
      ],
      'layout': _surfaceLayout(title, terrain, camera: camera, orthographic: true),
    };
  }

  static Map<String, dynamic> terrainWithContaminationAndDrone(
    Matrix2D terrain,
    Matrix2D contamination,
    List<List<double>> dronePath,
    List<double> values, {
    String title = 'Drone Scan Result',
  }) {
    final maxVal = values.isEmpty
        ? 1.0
        : values.reduce((a, b) => a > b ? a : b);
    final maxCont = contamination.maxValue() > 0
        ? contamination.maxValue()
        : 1.0;

    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(terrain),
          'surfacecolor': _normalizeFlipY(contamination),
          'colorscale': 'Reds',
          'cmin': 0,
          'cmax': 1,
          'showscale': true,
          'colorbar': {'title': 'Contamination'},
        },
        {
          'type': 'scatter3d',
          'mode': 'markers',
          'x': dronePath.map((p) => p[0]).toList(),
          'y': dronePath.map((p) => p[1]).toList(),
          'z': dronePath.map((p) => p[2]).toList(),
          'marker': {
            'size': 2,
            'color': _normalizeList(values),
            'colorscale': 'Jet',
            'cmin': 0,
            'cmax': 1,
            'showscale': true,
            'colorbar': {'title': 'Measurement', 'x': 1.1},
          },
        },
      ],
      'layout': _surfaceLayout(title, terrain, orthographic: true),
    };
  }

  static Map<String, dynamic> terrainWithContamination(
    Matrix2D terrain,
    Matrix2D contamination, {
    String title = 'Contamination Map',
    Map<String, dynamic>? camera,
  }) {
    final minCont = contamination.minValue();
    final maxCont = contamination.maxValue();
    final cmin = minCont.isFinite ? minCont : 0.0;
    final cmax = maxCont.isFinite && maxCont > cmin ? maxCont : cmin + 1.0;

    return {
      'data': [
        {
          'type': 'surface',
          'z': _flipY(terrain),
          'surfacecolor': _normalizeFlipY(contamination),
          'colorscale': 'Reds',
          'cmin': 0,
          'cmax': 1,
          'showscale': true,
          'colorbar': {'title': 'CPS', 'x': 1.02},
        },
      ],
      'layout': _surfaceLayout(title, terrain, camera: camera, orthographic: true),
    };
  }

  static Map<String, dynamic> heatmap(
    Matrix2D zData, {
    String title = '',
    String colorscale = 'Hot',
  }) {
    return {
      'data': [
        {'type': 'heatmap', 'z': zData.toList(), 'colorscale': colorscale},
      ],
      'layout': {
        ..._baseLayout(title),
        'yaxis': {'scaleanchor': 'x'},
      },
    };
  }

  static Map<String, dynamic> _surfaceLayout(String title, Matrix2D terrain,
      {Map<String, dynamic>? camera, bool orthographic = false}) {
    return {
      ..._baseLayout(title),
      'scene': _sceneLayout(terrain, camera: camera, orthographic: orthographic),
    };
  }

  static Map<String, dynamic> _baseLayout(String title) {
    return {
      'title': {
        'text': title,
        'font': {'color': '#ffffff'},
      },
      'paper_bgcolor': '#1a1a2e',
      'plot_bgcolor': '#1a1a2e',
      'font': {'color': '#cccccc'},
      'margin': {'l': 0, 'r': 0, 't': 40, 'b': 0},
    };
  }

  static Map<String, dynamic> _sceneLayout(Matrix2D terrain,
      {Map<String, dynamic>? camera, bool orthographic = false}) {
    final zRange = terrain.maxValue() - terrain.minValue();
    final xySize = (terrain.rows + terrain.cols) / 2.0;
    final zRatio = xySize > 0 ? (zRange / xySize).clamp(0.1, 1.0) : 0.2;
    return {
      'aspectmode': 'manual',
      'aspectratio': {'x': 1, 'y': 1, 'z': zRatio},
      'bgcolor': 'rgba(0,0,0,0)',
      'camera': camera ?? {
        'eye': {'x': -1.25, 'y': -1.25, 'z': 1.25},
      },
      if (orthographic) 'projection': {'type': 'orthographic'},
      'xaxis': {'backgroundcolor': 'rgba(0,0,0,0)', 'gridcolor': '#444'},
      'yaxis': {'backgroundcolor': 'rgba(0,0,0,0)', 'gridcolor': '#444'},
      'zaxis': {'backgroundcolor': 'rgba(0,0,0,0)', 'gridcolor': '#444'},
    };
  }
}
