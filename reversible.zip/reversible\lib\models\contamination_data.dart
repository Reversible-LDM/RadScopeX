import '../core/matrix2d.dart';

class ContaminationSource {
  final int row;
  final int col;
  final double strength;
  final double sigma;

  ContaminationSource({
    required this.row,
    required this.col,
    required this.strength,
    required this.sigma,
  });
}

class ContaminationData {
  final Matrix2D contaminationMap;
  final List<ContaminationSource> sources;

  ContaminationData({
    required this.contaminationMap,
    required this.sources,
  });
}
