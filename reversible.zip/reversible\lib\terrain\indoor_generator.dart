import 'dart:math';
import '../core/matrix2d.dart';

/// 실내 레이아웃 생성 (벽 = 1, 빈 공간 = 0)
Matrix2D generateIndoorLayout(int width, int height, {int? seed}) {
  final rng = seed != null ? Random(seed) : Random();
  final layout = Matrix2D.zeros(height, width);

  // 외벽
  for (int c = 0; c < width; c++) {
    layout.set(0, c, 1);
    layout.set(height - 1, c, 1);
  }
  for (int r = 0; r < height; r++) {
    layout.set(r, 0, 1);
    layout.set(r, width - 1, 1);
  }

  // 내부 벽 (랜덤 사각형 2~4개)
  final numWalls = 2 + rng.nextInt(3);
  for (int i = 0; i < numWalls; i++) {
    final isHorizontal = rng.nextBool();
    if (isHorizontal) {
      final row = 2 + rng.nextInt(max(1, height - 4));
      final startCol = 1 + rng.nextInt(max(1, width ~/ 3));
      final endCol = startCol + rng.nextInt(max(1, width ~/ 2));
      // 문 위치
      final doorPos = startCol + rng.nextInt(max(1, endCol - startCol));
      for (int c = startCol; c < min(endCol, width - 1); c++) {
        if (c != doorPos) {
          layout.set(row, c, 1);
        }
      }
    } else {
      final col = 2 + rng.nextInt(max(1, width - 4));
      final startRow = 1 + rng.nextInt(max(1, height ~/ 3));
      final endRow = startRow + rng.nextInt(max(1, height ~/ 2));
      final doorPos = startRow + rng.nextInt(max(1, endRow - startRow));
      for (int r = startRow; r < min(endRow, height - 1); r++) {
        if (r != doorPos) {
          layout.set(r, col, 1);
        }
      }
    }
  }

  return layout;
}
