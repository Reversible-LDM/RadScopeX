import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/terrain_provider.dart';
import '../providers/simulation_provider.dart';
import '../providers/prediction_provider.dart';
import '../providers/contamination_provider.dart';
import '../simulation/outdoor_simulation.dart';
import '../model/model_manager.dart';
import '../model/model_utils.dart';
import '../models/prediction_result.dart';
import '../widgets/plotly_webview.dart';
import '../widgets/plotly_chart_builder.dart';
import '../services/training_service.dart';

class TrainingPage extends ConsumerStatefulWidget {
  const TrainingPage({super.key});

  @override
  ConsumerState<TrainingPage> createState() => _TrainingPageState();
}

class _TrainingPageState extends ConsumerState<TrainingPage> {
  final _trainingService = TrainingService();
  final _modelManager = ModelManager();
  bool _isOnline = false;
  bool _isTraining = false;
  String _statusMessage = '';
  List<String> _availableModels = [];
  List<String> _localModels = [];
  String? _selectedModel;

  int _numSamples = 100;
  int _epochs = 20;

  @override
  void initState() {
    super.initState();
    _checkConnection();
    _loadModelList();
  }

  Future<void> _checkConnection() async {
    final online = await _trainingService.checkConnection();
    if (mounted) setState(() => _isOnline = online);
  }

  Future<void> _loadModelList() async {
    final all = await _modelManager.listAllModels();
    final local = await _modelManager.listLocalModels();
    if (mounted) {
      setState(() {
        _availableModels = all;
        _localModels = local;
        if (_selectedModel == null && all.isNotEmpty) {
          _selectedModel = all.first;
        }
      });
    }
  }

  @override
  void dispose() {
    _modelManager.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final terrain = ref.watch(terrainProvider).terrain;
    final simState = ref.watch(simulationProvider);
    final predState = ref.watch(predictionProvider);
    final contamination = ref.watch(contaminationProvider).contamination;

    if (terrain == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('4. AI 학습/예측')),
        body: const Center(child: Text('먼저 지형을 생성해주세요.')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('4. AI 학습/예측'),
        actions: [
          IconButton(
            onPressed: _checkConnection,
            icon: Icon(
              _isOnline ? Icons.cloud_done : Icons.cloud_off,
              color: _isOnline ? Colors.green : Colors.grey,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 온라인 학습 섹션
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('온라인 학습',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          _isOnline ? Icons.cloud_done : Icons.cloud_off,
                          color: _isOnline ? Colors.green : Colors.grey,
                        ),
                        const SizedBox(width: 8),
                        Text(_isOnline ? '서버 연결됨' : '서버 오프라인'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: const InputDecoration(
                              labelText: '샘플 수 (Samples)',
                              border: OutlineInputBorder(),
                              hintText: '10 이상',
                            ),
                            keyboardType: TextInputType.number,
                            controller: TextEditingController(text: '$_numSamples'),
                            onChanged: (v) {
                              final n = int.tryParse(v);
                              if (n != null && n >= 10) {
                                setState(() => _numSamples = n);
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            decoration: const InputDecoration(
                              labelText: '학습 반복 (Epochs)',
                              border: OutlineInputBorder(),
                              hintText: '5 이상',
                            ),
                            keyboardType: TextInputType.number,
                            controller: TextEditingController(text: '$_epochs'),
                            onChanged: (v) {
                              final n = int.tryParse(v);
                              if (n != null && n >= 5) {
                                setState(() => _epochs = n);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed:
                          _isOnline && !_isTraining ? _startTraining : null,
                      icon: _isTraining
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2),
                            )
                          : const Icon(Icons.model_training),
                      label: Text(_isTraining ? '학습 중...' : '모델 학습 (서버)'),
                    ),
                    if (_statusMessage.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(_statusMessage,
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.secondary)),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // 오프라인 예측 섹션
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('오프라인 예측',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),

                    // 모델 목록
                    ..._availableModels.map((m) {
                      final isLocal = _localModels.contains(m);
                      final isSelected = _selectedModel == m;
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(
                          isLocal ? Icons.download_done : Icons.inventory_2,
                          size: 18,
                          color: isLocal ? Colors.green : Colors.grey,
                        ),
                        title: Text(
                          m,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                        subtitle: Text(
                          isLocal ? '다운로드됨' : '내장',
                          style: TextStyle(
                            fontSize: 11,
                            color: isLocal ? Colors.green : Colors.grey,
                          ),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isSelected)
                              const Icon(Icons.check_circle, size: 18, color: Colors.blue),
                            if (isLocal)
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 18, color: Colors.redAccent),
                                tooltip: '삭제',
                                onPressed: () => _deleteModel(m),
                              ),
                          ],
                        ),
                        onTap: () => setState(() => _selectedModel = m),
                      );
                    }),
                    const SizedBox(height: 8),

                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        FilledButton.icon(
                          onPressed: simState.measurement != null &&
                                  !predState.isRunning
                              ? _runIdwPrediction
                              : null,
                          icon: const Icon(Icons.grid_on),
                          label: const Text('IDW 보간'),
                        ),
                        FilledButton.icon(
                          onPressed: simState.measurement != null &&
                                  !predState.isRunning &&
                                  _selectedModel != null
                              ? _runTflitePrediction
                              : null,
                          icon: const Icon(Icons.psychology),
                          label: const Text('AI 예측 (TFLite)'),
                        ),
                      ],
                    ),
                    if (predState.error != null) ...[
                      const SizedBox(height: 8),
                      Text(predState.error!,
                          style: const TextStyle(color: Colors.redAccent)),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // 결과 시각화 - 3개 가로 배치
            if (contamination != null && (predState.idwResult != null || predState.result != null)) ...[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ground Truth
                  Expanded(
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Column(
                          children: [
                            Text('Ground Truth',
                                style: Theme.of(context).textTheme.titleSmall),
                            const SizedBox(height: 8),
                            PlotlyWebView(
                              height: 300,
                              chartSpec: PlotlyChartBuilder.terrainWithContamination(
                                terrain.elevation,
                                contamination.contaminationMap,
                                title: 'Ground Truth',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // IDW
                  if (predState.idwResult != null) ...[
                    const SizedBox(width: 8),
                    Expanded(
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            children: [
                              Text('IDW 보간',
                                  style: Theme.of(context).textTheme.titleSmall),
                              const SizedBox(height: 8),
                              PlotlyWebView(
                                height: 300,
                                chartSpec: PlotlyChartBuilder.terrainWithContamination(
                                  terrain.elevation,
                                  predState.idwResult!,
                                  title: 'IDW 보간',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                  // AI 예측
                  if (predState.result != null) ...[
                    const SizedBox(width: 8),
                    Expanded(
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Column(
                            children: [
                              Text(
                                'AI 예측 (${predState.result!.elapsed.inMilliseconds}ms)',
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                              const SizedBox(height: 8),
                              PlotlyWebView(
                                height: 300,
                                chartSpec: PlotlyChartBuilder.terrainWithContamination(
                                  terrain.elevation,
                                  predState.result!.prediction,
                                  title: 'AI 예측',
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _startTraining() async {
    setState(() { _isTraining = true; _statusMessage = '학습 시작...'; });

    try {
      final terrain = ref.read(terrainProvider).terrain!;
      final altitude = ref.read(simulationProvider).altitude;

      final jobId = await _trainingService.startTrainingAsync(
        terrainType: terrain.type,
        altitude: altitude,
        numSamples: _numSamples,
        epochs: _epochs,
      );

      setState(() => _statusMessage = 'AI 학습 중... (시간이 걸릴 수 있습니다)');
      Map<String, dynamic> result = {};
      while (true) {
        await Future.delayed(const Duration(seconds: 5));
        if (!mounted) return;
        final status = await _trainingService.getTrainingStatus(jobId);
        if (status['status'] == 'done') {
          result = status;
          break;
        } else if (status['status'] == 'error') {
          throw Exception(status['error'] ?? '학습 실패');
        } else if (status['status'] == 'not_found') {
          result = {'model_name': '${terrain.type}_${terrain.rows}x${terrain.cols}_${altitude.toInt()}m'};
          break;
        }
      }

      final modelName = (result['model_name'] as String?)
          ?? '${terrain.type}_${terrain.rows}x${terrain.cols}_${altitude.toInt()}m';

      setState(() => _statusMessage = '모델 다운로드 중...');
      try {
        final bytes = await _trainingService.downloadModel(modelName);
        await _modelManager.saveModel(modelName, bytes);
        setState(() { _statusMessage = '완료! 저장됨: $modelName'; _isTraining = false; });
        await _loadModelList();
        setState(() => _selectedModel = modelName);
      } catch (downloadErr) {
        setState(() { _statusMessage = '학습 완료 (다운로드 실패: $downloadErr)'; _isTraining = false; });
        await _loadModelList();
      }
    } catch (e) {
      setState(() { _statusMessage = '학습 실패: $e'; _isTraining = false; });
    }
  }

  Future<void> _deleteModel(String modelName) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('모델 삭제'),
        content: Text('\'$modelName\' 를 삭제하시겠습니까?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('취소')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('삭제', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (ok != true) return;
    await _modelManager.deleteModel(modelName);
    if (_selectedModel == modelName) {
      setState(() => _selectedModel = null);
    }
    await _loadModelList();
  }

  void _runIdwPrediction() {
    final terrain = ref.read(terrainProvider).terrain!;
    final measurement = ref.read(simulationProvider).measurement!;
    ref.read(predictionProvider.notifier).setRunning(true);

    Future.microtask(() {
      final idw = idwInterpolation(
        measurement,
        terrain.rows,
        terrain.cols,
      );
      ref.read(predictionProvider.notifier).setIdwResult(idw);
    });
  }

  Future<void> _runTflitePrediction() async {
    if (_selectedModel == null) return;

    final terrain = ref.read(terrainProvider).terrain!;
    final measurement = ref.read(simulationProvider).measurement!;
    final altitude = ref.read(simulationProvider).altitude;

    ref.read(predictionProvider.notifier).setRunning(true);

    try {
      await _modelManager.loadModel(_selectedModel!);

      // 입력 데이터 생성
      final inputData = formatMeasurementsForModel(
        measurement,
        terrain.elevation,
        altitude,
      );

      // 패딩 적용
      final (padH, padW) =
          computePaddedShapeForModel(terrain.rows, terrain.cols);
      final paddedInput = padInput4D(inputData, padH, padW);

      // 추론
      final stopwatch = Stopwatch()..start();
      final prediction = _modelManager.runner.predict(paddedInput);
      stopwatch.stop();

      // 원래 크기로 crop
      final cropped = cropOutput(prediction, terrain.rows, terrain.cols);

      ref.read(predictionProvider.notifier).setResult(
            PredictionResult(
              prediction: cropped,
              modelName: _selectedModel!,
              elapsed: stopwatch.elapsed,
            ),
          );
    } catch (e) {
      ref.read(predictionProvider.notifier).setError('TFLite 예측 실패: $e');
    }
  }
}
