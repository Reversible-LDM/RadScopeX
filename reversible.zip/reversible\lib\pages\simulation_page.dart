import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/terrain_provider.dart';
import '../providers/contamination_provider.dart';
import '../providers/simulation_provider.dart';
import '../simulation/outdoor_simulation.dart';
import '../widgets/plotly_webview.dart';
import '../widgets/plotly_chart_builder.dart';

class SimulationPage extends ConsumerStatefulWidget {
  const SimulationPage({super.key});

  @override
  ConsumerState<SimulationPage> createState() => _SimulationPageState();
}

class _SimulationPageState extends ConsumerState<SimulationPage> {
  double _altitude = 30.0;
  int _numLines = 20;

  @override
  Widget build(BuildContext context) {
    final terrain = ref.watch(terrainProvider).terrain;
    final contamination =
        ref.watch(contaminationProvider).contamination;
    final simState = ref.watch(simulationProvider);

    if (terrain == null || contamination == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('3. 드론 시뮬레이션')),
        body: const Center(child: Text('먼저 지형과 오염원을 설정해주세요.')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('3. 드론 시뮬레이션')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('비행 고도: ${_altitude.toStringAsFixed(0)}m'),
                    Slider(
                      value: _altitude,
                      min: 5,
                      max: 100,
                      onChanged: (v) => setState(() => _altitude = v),
                    ),
                    Text('스캔 라인 수: $_numLines'),
                    Slider(
                      value: _numLines.toDouble(),
                      min: 5,
                      max: 50,
                      divisions: 45,
                      onChanged: (v) =>
                          setState(() => _numLines = v.round()),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: simState.isRunning
                          ? null
                          : () => _runSimulation(terrain, contamination),
                      icon: simState.isRunning
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2),
                            )
                          : const Icon(Icons.flight),
                      label: Text(
                          simState.isRunning ? '시뮬레이션 중...' : '시뮬레이션 시작'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            if (simState.measurement != null) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Text(
                        '측정점 ${simState.measurement!.length}개',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      PlotlyWebView(
                        height: 350,
                        chartSpec:
                            PlotlyChartBuilder.terrainWithContaminationAndDrone(
                          terrain.elevation,
                          contamination.contaminationMap,
                          simState.measurement!.path
                              .map((p) => p.toList())
                              .toList(),
                          simState.measurement!.values,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _runSimulation(dynamic terrain, dynamic contamination) {
    ref.read(simulationProvider.notifier).setRunning(true);

    // isolate 대신 Future.microtask로 실행 (UI 블로킹 최소화)
    Future.microtask(() {
      final measurement = runDroneScan(
        terrain.elevation,
        contamination.contaminationMap,
        _altitude,
        numLines: _numLines,
      );
      ref.read(simulationProvider.notifier).setMeasurement(measurement);
    });
  }
}
