import 'dart:math';
import 'dart:typed_data';
import 'matrix2d.dart';

/// scipy.ndimage.gaussian_filter 대체.
/// 분리형(separable) 가우시안 컨볼루션 구현.
/// 가로 방향 1D 가우시안 → 세로 방향 1D 가우시안 순서로 적용.
Matrix2D gaussianFilter(Matrix2D input, double sigma) {
  if (sigma <= 0) return input.copy();

  // 커널 반경: 4*sigma 까지 (scipy 기본 truncate=4.0)
  final radius = (sigma * 4).ceil();
  final kernel = _makeGaussianKernel1D(sigma, radius);

  // 가로 방향 컨볼루션
  final temp = _convolve1DHorizontal(input, kernel, radius);
  // 세로 방향 컨볼루션
  final result = _convolve1DVertical(temp, kernel, radius);

  return result;
}

/// 1D 가우시안 커널 생성 (합계 1로 정규화)
Float64List _makeGaussianKernel1D(double sigma, int radius) {
  final size = 2 * radius + 1;
  final kernel = Float64List(size);
  double sum = 0;
  final s2 = 2 * sigma * sigma;
  for (int i = -radius; i <= radius; i++) {
    final v = exp(-(i * i) / s2);
    kernel[i + radius] = v;
    sum += v;
  }
  // 정규화
  for (int i = 0; i < size; i++) {
    kernel[i] /= sum;
  }
  return kernel;
}

/// 가로 방향 1D 컨볼루션 (reflect 경계)
Matrix2D _convolve1DHorizontal(Matrix2D input, Float64List kernel, int radius) {
  final rows = input.rows;
  final cols = input.cols;
  final result = Matrix2D(rows, cols);

  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      double sum = 0;
      for (int k = -radius; k <= radius; k++) {
        int cc = c + k;
        // reflect 경계 처리
        if (cc < 0) cc = -cc;
        if (cc >= cols) cc = 2 * cols - 2 - cc;
        cc = cc.clamp(0, cols - 1);
        sum += input.get(r, cc) * kernel[k + radius];
      }
      result.set(r, c, sum);
    }
  }
  return result;
}

/// 세로 방향 1D 컨볼루션 (reflect 경계)
Matrix2D _convolve1DVertical(Matrix2D input, Float64List kernel, int radius) {
  final rows = input.rows;
  final cols = input.cols;
  final result = Matrix2D(rows, cols);

  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      double sum = 0;
      for (int k = -radius; k <= radius; k++) {
        int rr = r + k;
        // reflect 경계 처리
        if (rr < 0) rr = -rr;
        if (rr >= rows) rr = 2 * rows - 2 - rr;
        rr = rr.clamp(0, rows - 1);
        sum += input.get(rr, c) * kernel[k + radius];
      }
      result.set(r, c, sum);
    }
  }
  return result;
}
