import 'dart:math';
import '../core/matrix2d.dart';
import '../core/gaussian_filter.dart';
import '../core/math_utils.dart';
import '../models/drone_measurement.dart';

/// 가우시안 오염원 추가
Matrix2D addGaussianSource(
  Matrix2D contaminationMap,
  int posY,
  int posX, {
  double strength = 100,
  double sigma = 5,
}) {
  final temp = Matrix2D.zeros(contaminationMap.rows, contaminationMap.cols);
  temp.set(posY, posX, strength);
  final gaussianSource = gaussianFilter(temp, sigma);
  return contaminationMap + gaussianSource;
}

/// AGL(Above Ground Level) 맵 계산
Matrix2D computeAglMap(Matrix2D terrain, double altitude, {bool clip = true}) {
  final alt = (altitude.isFinite && altitude > 0) ? altitude : 30.0;
  final result = terrain.map((t) => alt - t);
  return clip ? result.clampMin(0.0) : result;
}

/// AGL 정규화
Matrix2D normalizeAgl(Matrix2D agl, double altitude) {
  final alt = (altitude.isFinite && altitude > 1e-8) ? altitude : 30.0;
  return agl.nanToZero().map((v) => max(v / alt, 0.0));
}

/// 지형 [0,1] 정규화
Matrix2D normalizeTerrain(Matrix2D terrain) {
  return terrain.nanToZero().normalize01();
}

/// 드론 스캔 시뮬레이션 - Python run_drone_scan() 포팅
DroneMeasurement runDroneScan(
  Matrix2D terrain,
  Matrix2D contamination,
  double altitude, {
  int numLines = 20,
  Map<String, double>? coordNorm,
}) {
  final ySize = terrain.rows;
  final xSize = terrain.cols;

  final alt =
      (altitude.isFinite && altitude > 0) ? altitude : 30.0;

  final cn = coordNorm ?? {'dx_m': 1.0, 'dy_m': 1.0, 'xy_unit': 1.0};
  final dxM = cn['dx_m'] ?? 1.0;
  final dyM = cn['dy_m'] ?? 1.0;
  final xyUnit = max(cn['xy_unit'] ?? 1.0, 1e-6);
  final dxNorm = dxM / xyUnit;
  final dyNorm = dyM / xyUnit;
  final altNorm = alt / xyUnit;

  // 정규화 지형
  final terrainNorm = terrain.scale(1.0 / xyUnit);

  // 표면 법선 계산
  final (gradY, gradX) = gradient2D(terrainNorm, dyNorm, dxNorm);

  // 오염원 위치 추출
  final sourceIndices = contamination.argWhere((v) => v > 0.1);
  final hasSources = sourceIndices.isNotEmpty;

  // 오염원 정보 사전 계산
  final sourcePositions = <List<double>>[];
  final sourceStrengths = <double>[];
  final sourceNormals = <List<double>>[];

  if (hasSources) {
    for (final (sy, sx) in sourceIndices) {
      sourcePositions
          .add([sx * dxNorm, sy * dyNorm, terrainNorm.get(sy, sx)]);
      sourceStrengths.add(contamination.get(sy, sx));

      final gx = -gradX.get(sy, sx);
      final gy = -gradY.get(sy, sx);
      const gz = 1.0;
      final n = norm3(gx, gy, gz);
      final invN = n > 1e-12 ? 1.0 / n : 0.0;
      sourceNormals.add([gx * invN, gy * invN, gz * invN]);
    }
  }

  final dronePath = <DronePoint>[];
  final measuredValues = <double>[];

  // 스캔 라인
  final nLines = max(1, numLines);
  final yCoordsList = linspace(0, (ySize - 1).toDouble(), nLines)
      .map((v) => v.round())
      .toSet()
      .toList()
    ..sort();

  for (int idx = 0; idx < yCoordsList.length; idx++) {
    final y = yCoordsList[idx];
    final xRange =
        idx % 2 == 0 ? arange(0, xSize) : arange(0, xSize).reversed.toList();

    for (final x in xRange) {
      // 지형보다 낮으면 건너뜀
      if (alt < terrain.get(y, x)) continue;

      dronePath.add(DronePoint(x.toDouble(), y.toDouble(), alt));

      if (!hasSources) {
        measuredValues.add(0.0);
        continue;
      }

      final droneX = x * dxNorm;
      final droneY = y * dyNorm;

      double totalSignal = 0;
      for (int s = 0; s < sourcePositions.length; s++) {
        final sp = sourcePositions[s];
        final vecX = droneX - sp[0];
        final vecY = droneY - sp[1];
        final vecZ = altNorm - sp[2];
        final distSq = vecX * vecX + vecY * vecY + vecZ * vecZ;

        if (distSq <= 1.0) continue;

        final invDist = 1.0 / sqrt(distSq);
        final nvX = vecX * invDist;
        final nvY = vecY * invDist;
        final nvZ = vecZ * invDist;

        final sn = sourceNormals[s];
        final directionality =
            max(0.0, nvX * sn[0] + nvY * sn[1] + nvZ * sn[2]);

        totalSignal += (sourceStrengths[s] / distSq) * directionality;
      }

      measuredValues.add(totalSignal * 100.0);
    }
  }

  return DroneMeasurement(path: dronePath, values: measuredValues);
}

/// 모델 입력 포맷 변환 - format_measurements_for_model() 포팅
/// 반환: (1, H, W, channels) 형태의 3D 리스트
List<List<List<List<double>>>> formatMeasurementsForModel(
  DroneMeasurement measurement,
  Matrix2D terrain,
  double altitude, {
  int channels = 3,
  bool includeAgl = true,
}) {
  final H = terrain.rows;
  final W = terrain.cols;

  final sparse = Matrix2D.zeros(H, W);
  final mask = Matrix2D.zeros(H, W);

  for (int i = 0; i < measurement.length; i++) {
    final p = measurement.path[i];
    final x = p.x.toInt();
    final y = p.y.toInt();
    if (y >= 0 && y < H && x >= 0 && x < W) {
      sparse.set(y, x, measurement.values[i]);
      mask.set(y, x, 1.0);
    }
  }

  Matrix2D? third;
  if (channels >= 3 && includeAgl) {
    final agl = computeAglMap(terrain, altitude, clip: false);
    third = normalizeAgl(agl, altitude);
  }

  // (1, H, W, C) 형태로 패킹
  return [
    List.generate(H, (r) {
      return List.generate(W, (c) {
        final ch = <double>[sparse.get(r, c)];
        if (channels >= 2) ch.add(mask.get(r, c));
        if (channels >= 3) ch.add(third?.get(r, c) ?? 0.0);
        return ch;
      });
    })
  ];
}

/// IDW 보간 - 2D (XY only)
Matrix2D idwInterpolation(
  DroneMeasurement measurement,
  int rows,
  int cols, {
  double power = 2.0,
  double smoothing = 1e-6,
  double? targetScale,
  Map<String, double>? coordNorm,
  bool snapMeasurements = true,
  double smoothSigma = 0.0,
}) {
  if (measurement.length == 0) return Matrix2D.zeros(rows, cols);

  final cn = coordNorm ?? {'dx_m': 1.0, 'dy_m': 1.0, 'xy_unit': 1.0};
  final xyUnit = max(cn['xy_unit'] ?? 1.0, 1e-6);
  final dxNorm = (cn['dx_m'] ?? 1.0) / xyUnit;
  final dyNorm = (cn['dy_m'] ?? 1.0) / xyUnit;

  // 좌표 & 값 추출
  final coords = <List<double>>[];
  final values = <double>[];
  for (int i = 0; i < measurement.length; i++) {
    final v = measurement.values[i];
    if (v.isFinite) {
      coords.add([measurement.path[i].x * dxNorm, measurement.path[i].y * dyNorm]);
      values.add(v);
    }
  }
  if (coords.isEmpty) return Matrix2D.zeros(rows, cols);

  // 스케일링
  if (targetScale != null) {
    double maxVal = 0;
    for (final v in values) {
      if (v.abs() > maxVal) maxVal = v.abs();
    }
    if (maxVal > 0) {
      final scale = targetScale / maxVal;
      for (int i = 0; i < values.length; i++) {
        values[i] *= scale;
      }
    }
  }

  final result = Matrix2D.zeros(rows, cols);

  for (int r = 0; r < rows; r++) {
    final gy = r * dyNorm;
    for (int c = 0; c < cols; c++) {
      final gx = c * dxNorm;
      double weightedSum = 0;
      double weightSum = 0;

      for (int k = 0; k < coords.length; k++) {
        final dx = gx - coords[k][0];
        final dy = gy - coords[k][1];
        final distSq = dx * dx + dy * dy;
        final w = 1.0 / pow(distSq + smoothing, power / 2.0);
        weightedSum += w * values[k];
        weightSum += w;
      }

      result.set(r, c, weightSum > 0 ? weightedSum / weightSum : 0.0);
    }
  }

  // 가우시안 스무딩
  final smoothed =
      smoothSigma > 0 ? gaussianFilter(result, smoothSigma) : result;

  // 측정점 스냅
  if (snapMeasurements) {
    for (int k = 0; k < coords.length; k++) {
      final xi = coords[k][0].round();
      final yi = coords[k][1].round();
      if (yi >= 0 && yi < rows && xi >= 0 && xi < cols) {
        smoothed.set(yi, xi, values[k]);
      }
    }
  }

  return smoothed;
}
