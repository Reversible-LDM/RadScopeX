import 'dart:io';
import 'package:tflite_flutter/tflite_flutter.dart';
import '../core/matrix2d.dart';

/// TFLite 모델 로드 + 추론
class TfliteRunner {
  Interpreter? _interpreter;

  bool get isLoaded => _interpreter != null;

  /// assets에서 모델 로드
  Future<void> loadFromAsset(String assetPath) async {
    _interpreter?.close();
    _interpreter = await Interpreter.fromAsset(assetPath);
  }

  /// 파일 경로에서 모델 로드
  Future<void> loadFromFile(String filePath) async {
    _interpreter?.close();
    _interpreter = Interpreter.fromFile(File(filePath));
  }

  /// 추론 실행
  /// input: (1, H, W, C) 형태의 4D 리스트
  /// 반환: (H, W) Matrix2D
  Matrix2D predict(List<List<List<List<double>>>> input) {
    if (_interpreter == null) {
      throw StateError('모델이 로드되지 않았습니다.');
    }

    final outputShape = _interpreter!.getOutputTensor(0).shape;
    // outputShape: [1, H, W, 1]

    final h = outputShape[1];
    final w = outputShape[2];

    // 출력 버퍼 할당
    final output = List.generate(
      1,
      (_) => List.generate(
        h,
        (_) => List.generate(w, (_) => List.filled(1, 0.0)),
      ),
    );

    _interpreter!.run(input, output);

    // Matrix2D로 변환 + clip(0, ∞)
    final result = Matrix2D(h, w);
    for (int r = 0; r < h; r++) {
      for (int c = 0; c < w; c++) {
        final v = output[0][r][c][0];
        result.set(r, c, v > 0 ? v : 0.0);
      }
    }
    return result;
  }

  /// 모델 입력 형태 반환 [1, H, W, C]
  List<int>? get inputShape => _interpreter?.getInputTensor(0).shape;

  /// 모델 출력 형태 반환 [1, H, W, 1]
  List<int>? get outputShape => _interpreter?.getOutputTensor(0).shape;

  void dispose() {
    _interpreter?.close();
    _interpreter = null;
  }
}
