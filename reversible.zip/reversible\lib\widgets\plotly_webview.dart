import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:webview_flutter/webview_flutter.dart';

class PlotlyWebView extends StatefulWidget {
  final Map<String, dynamic>? chartSpec;
  final double height;
  const PlotlyWebView({super.key, this.chartSpec, this.height = 400});
  @override
  State<PlotlyWebView> createState() => _PlotlyWebViewState();
}

class _PlotlyWebViewState extends State<PlotlyWebView> {
  final _controller = WebViewController();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF1a1a2e))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          _ready = true;
          _updateChart();
        },
      ))
      ..loadFlutterAsset('assets/html/plotly_template.html');
  }

  @override
  void didUpdateWidget(PlotlyWebView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.chartSpec != oldWidget.chartSpec) _updateChart();
  }

  void _updateChart() {
    if (!_ready || widget.chartSpec == null) return;
    final json = jsonEncode(widget.chartSpec);
    final escaped = json.replaceAll('\\', '\\\\').replaceAll("'", "\\'");
    _controller.runJavaScript("renderChart('$escaped')");
  }

  void _zoom(double factor) {
    _controller.runJavaScript('''
      (function() {
        var el = document.getElementById('chart');
        var cam = (el.layout && el.layout.scene && el.layout.scene.camera)
          ? el.layout.scene.camera
          : {eye: {x:1.25, y:1.25, z:1.25}};
        Plotly.relayout('chart', {'scene.camera.eye': {
          x: cam.eye.x * $factor,
          y: cam.eye.y * $factor,
          z: cam.eye.z * $factor
        }});
      })();
    ''');
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height,
      child: Stack(
        children: [
          WebViewWidget(
            controller: _controller,
            // Let the embedded Plotly view claim drags/pinches so 3D rotation
            // is not intercepted by parent Flutter scroll views.
            gestureRecognizers: {
              Factory<OneSequenceGestureRecognizer>(
                () => EagerGestureRecognizer(),
              ),
            },
          ),
          Positioned(
            right: 12,
            bottom: 12,
            child: Column(
              children: [
                FloatingActionButton.small(
                  heroTag: 'zoom_in_$hashCode',
                  onPressed: () => _zoom(0.7),
                  child: const Icon(Icons.add),
                ),
                const SizedBox(height: 8),
                FloatingActionButton.small(
                  heroTag: 'zoom_out_$hashCode',
                  onPressed: () => _zoom(1.4),
                  child: const Icon(Icons.remove),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
