class DronePoint {
  final double x;
  final double y;
  final double z;

  DronePoint(this.x, this.y, this.z);

  List<double> toList() => [x, y, z];
}

class DroneMeasurement {
  final List<DronePoint> path;
  final List<double> values;

  DroneMeasurement({required this.path, required this.values});

  int get length => path.length;

  Map<String, dynamic> toPathValues() => {
        'path': path.map((p) => p.toList()).toList(),
        'values': values,
      };
}
