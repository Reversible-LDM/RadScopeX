import 'dart:convert';
import 'package:http/http.dart' as http;

/// 서버와 통신하여 모델 학습을 수행하는 서비스.
/// 오직 학습만 온라인으로 처리한다.
class TrainingService {
  String _serverUrl;

  TrainingService({String serverUrl = 'http://172.27.132.78:30000'})
      : _serverUrl = serverUrl;

  String get serverUrl => _serverUrl;

  void setServerUrl(String url) {
    _serverUrl = url;
  }

  /// 서버 연결 확인
  Future<bool> checkConnection() async {
    try {
      final response = await http
          .get(Uri.parse(_serverUrl))
          .timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// 비동기 학습 시작 → job_id 반환
  Future<String> startTrainingAsync({
    required String terrainType,
    int numSamples = 100,
    int epochs = 20,
    double altitude = 30.0,
    String? modelTag,
  }) async {
    final body = {
      'terrain_type': terrainType,
      'num_samples': numSamples,
      'epochs': epochs,
      'altitude': altitude,
      if (modelTag != null) 'model_tag': modelTag,
    };
    final response = await http.post(
      Uri.parse('$_serverUrl/api/start_training_async'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) {
      throw Exception('학습 시작 실패: ${response.statusCode}');
    }
    return (jsonDecode(response.body) as Map)['job_id'] as String;
  }

  /// 학습 상태 조회
  Future<Map<String, dynamic>> getTrainingStatus(String jobId) async {
    final response = await http.get(
      Uri.parse('$_serverUrl/api/training_status/$jobId'),
    ).timeout(const Duration(seconds: 10));
    if (response.statusCode == 404) return {'status': 'not_found'};
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  /// 모델 학습 시작 (동기 — 하위 호환)
  Future<Map<String, dynamic>> startTraining({
    required String terrainType,
    int numSamples = 100,
    int epochs = 20,
    double altitude = 30.0,
    String? modelTag,
  }) async {
    final body = {
      'terrain_type': terrainType,
      'num_samples': numSamples,
      'epochs': epochs,
      'altitude': altitude,
if (modelTag != null) 'model_tag': modelTag,
    };

    final response = await http.post(
      Uri.parse('$_serverUrl/api/start_training'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(hours: 2));

    if (response.statusCode == 200) {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } else {
      throw Exception('학습 실패: ${response.statusCode} ${response.body}');
    }
  }

  /// 학습된 TFLite 모델 다운로드
  Future<List<int>> downloadModel(String modelName) async {
    final response = await http.get(
      Uri(
        scheme: Uri.parse(_serverUrl).scheme,
        host: Uri.parse(_serverUrl).host,
        port: Uri.parse(_serverUrl).port,
        path: '/api/download_model',
        queryParameters: {'name': modelName},
      ),
    );

    if (response.statusCode == 200) {
      return response.bodyBytes;
    } else {
      throw Exception('모델 다운로드 실패: ${response.statusCode}');
    }
  }
}
