import 'dart:convert';
import 'package:http/http.dart' as http;

/// 서버 필드 분석 API 호출 서비스.
/// Flask 세션 쿠키를 유지하여 여러 API 호출 간 상태를 공유한다.
class FieldService {
  final String serverUrl;
  String? _sessionCookie;

  FieldService(this.serverUrl);

  Map<String, String> get _cookieHeader =>
      _sessionCookie != null ? {'Cookie': _sessionCookie!} : {};

  void _saveCookie(http.BaseResponse res) {
    final c = res.headers['set-cookie'];
    if (c != null) _sessionCookie = c;
  }

  /// 1. 등고선 shapefile + 드론 CSV로 DEM 생성 (세션에 지형 저장)
  Future<Map<String, dynamic>> generateTerrain({
    required String csvPath,
    required String shpDir,
    required String modelName,
    int halfSizeM = 50,
  }) async {
    final req = http.MultipartRequest(
      'POST',
      Uri.parse('$serverUrl/api/field_generate_terrain'),
    );
    req.headers.addAll(_cookieHeader);
    req.files.add(await http.MultipartFile.fromPath('csv_file', csvPath));
    req.fields['shp_dir'] = shpDir;
    req.fields['model_name'] = modelName;
    req.fields['half_size_m'] = halfSizeM.toString();

    final streamed = await req.send().timeout(const Duration(seconds: 30));
    _saveCookie(streamed);
    final res = await http.Response.fromStream(streamed);

    if (res.statusCode != 200) {
      final err = (jsonDecode(res.body) as Map)['error'] ?? '서버 오류';
      throw Exception(err);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// 2. 드론 CSV 업로드 → IDW 분석 + 드론 경로 반환
  Future<Map<String, dynamic>> uploadFieldData({
    required String csvPath,
    required String valueCol,
    required String altCol,
    double idwPower = 2.0,
  }) async {
    final req = http.MultipartRequest(
      'POST',
      Uri.parse('$serverUrl/api/upload_field_data'),
    );
    req.headers.addAll(_cookieHeader);
    req.files.add(await http.MultipartFile.fromPath('field_file', csvPath));
    req.fields['value_col'] = valueCol;
    req.fields['alt_col'] = altCol;
    req.fields['idw_power'] = idwPower.toString();

    final streamed = await req.send().timeout(const Duration(seconds: 30));
    _saveCookie(streamed);
    final res = await http.Response.fromStream(streamed);

    if (res.statusCode != 200) {
      final err = (jsonDecode(res.body) as Map)['error'] ?? '서버 오류';
      throw Exception(err);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// 3. AI 모델 학습 시작 (비동기) → job_id 반환
  Future<String> startTrainAsync({
    required int numSamples,
    required int epochs,
    String? modelTag,
  }) async {
    final res = await http.post(
      Uri.parse('$serverUrl/api/field_train_async'),
      headers: {'Content-Type': 'application/json', ..._cookieHeader},
      body: jsonEncode({
        'num_samples': numSamples,
        'epochs': epochs,
        if (modelTag != null && modelTag.isNotEmpty) 'model_tag': modelTag,
      }),
    ).timeout(const Duration(seconds: 10));
    _saveCookie(res);
    if (res.statusCode != 200) {
      final err = (jsonDecode(res.body) as Map)['error'] ?? '학습 시작 실패';
      throw Exception(err);
    }
    return (jsonDecode(res.body) as Map)['job_id'] as String;
  }

  /// 학습 상태 조회
  Future<Map<String, dynamic>> getTrainStatus(String jobId) async {
    final res = await http.get(
      Uri.parse('$serverUrl/api/field_train_status/$jobId'),
      headers: _cookieHeader,
    ).timeout(const Duration(seconds: 10));
    _saveCookie(res);
    if (res.statusCode == 404) return {'status': 'not_found'};
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// 3. AI 모델 학습 (기존 동기 방식 — 하위 호환)
  Future<Map<String, dynamic>> trainModel({
    required int numSamples,
    required int epochs,
    String? modelTag,
  }) async {
    final res = await http.post(
      Uri.parse('$serverUrl/api/field_train'),
      headers: {'Content-Type': 'application/json', ..._cookieHeader},
      body: jsonEncode({
        'num_samples': numSamples,
        'epochs': epochs,
        if (modelTag != null && modelTag.isNotEmpty) 'model_tag': modelTag,
      }),
    ).timeout(const Duration(hours: 2));
    _saveCookie(res);

    if (res.statusCode != 200) {
      final err = (jsonDecode(res.body) as Map)['error'] ?? '학습 실패';
      throw Exception(err);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// 4. AI 예측
  Future<Map<String, dynamic>> predict() async {
    final res = await http.get(
      Uri.parse('$serverUrl/api/field_predict'),
      headers: _cookieHeader,
    ).timeout(const Duration(seconds: 60));
    _saveCookie(res);

    if (res.statusCode != 200) {
      final err = (jsonDecode(res.body) as Map)['error'] ?? '예측 실패';
      throw Exception(err);
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// 로컬 저장 지형을 서버 세션에 복원
  Future<void> restoreTerrain({
    required List<List<double>> zData,
    required double extentXm,
    required double extentYm,
    required String modelTag,
    Map<String, double>? bounds,
    String? crs,
    double terrainBaseAltitude = 0.0,
  }) async {
    final res = await http.post(
      Uri.parse('$serverUrl/api/field_restore_terrain'),
      headers: {'Content-Type': 'application/json', ..._cookieHeader},
      body: jsonEncode({
        'z_data': zData,
        'extent_x_m': extentXm,
        'extent_y_m': extentYm,
        'model_tag': modelTag,
        if (bounds != null) 'bounds': bounds,
        if (crs != null) 'crs': crs,
        'terrain_base_altitude_m': terrainBaseAltitude,
      }),
    ).timeout(const Duration(seconds: 30));
    _saveCookie(res);
    if (res.statusCode != 200) {
      throw Exception('지형 복원 실패: ${res.statusCode}');
    }
  }

  /// CSV 컬럼 목록 조회
  Future<Map<String, dynamic>> getColumns(String csvPath) async {
    final req = http.MultipartRequest(
      'POST',
      Uri.parse('$serverUrl/api/field_columns'),
    );
    req.files.add(await http.MultipartFile.fromPath('field_file', csvPath));
    final streamed = await req.send().timeout(const Duration(seconds: 10));
    final res = await http.Response.fromStream(streamed);
    if (res.statusCode != 200) return {};
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}
