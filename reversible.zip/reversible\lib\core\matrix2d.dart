import 'dart:math';
import 'dart:typed_data';

/// numpy 2D 배열 대체 클래스.
/// 내부적으로 Float64List 1D 배열을 사용하여 (rows x cols) 행렬을 표현한다.
class Matrix2D {
  final int rows;
  final int cols;
  final Float64List data;

  Matrix2D(this.rows, this.cols) : data = Float64List(rows * cols);

  Matrix2D.fromData(this.rows, this.cols, this.data);

  factory Matrix2D.zeros(int rows, int cols) {
    return Matrix2D(rows, cols);
  }

  factory Matrix2D.filled(int rows, int cols, double value) {
    final d = Float64List(rows * cols);
    for (int i = 0; i < d.length; i++) {
      d[i] = value;
    }
    return Matrix2D.fromData(rows, cols, d);
  }

  factory Matrix2D.fromList(List<List<double>> list) {
    final rows = list.length;
    final cols = rows > 0 ? list[0].length : 0;
    final d = Float64List(rows * cols);
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        d[r * cols + c] = list[r][c];
      }
    }
    return Matrix2D.fromData(rows, cols, d);
  }

  double get(int row, int col) => data[row * cols + col];

  void set(int row, int col, double value) {
    data[row * cols + col] = value;
  }

  Matrix2D copy() {
    return Matrix2D.fromData(rows, cols, Float64List.fromList(data));
  }

  /// 요소별 덧셈
  Matrix2D operator +(Matrix2D other) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = data[i] + other.data[i];
    }
    return result;
  }

  /// 요소별 뺄셈
  Matrix2D operator -(Matrix2D other) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = data[i] - other.data[i];
    }
    return result;
  }

  /// 스칼라 곱
  Matrix2D scale(double s) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = data[i] * s;
    }
    return result;
  }

  /// 요소별 곱
  Matrix2D elementMul(Matrix2D other) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = data[i] * other.data[i];
    }
    return result;
  }

  /// 요소별 나눗셈 (0으로 나누면 0)
  Matrix2D elementDiv(Matrix2D other) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = other.data[i] != 0 ? data[i] / other.data[i] : 0.0;
    }
    return result;
  }

  /// 요소별 함수 적용
  Matrix2D map(double Function(double) fn) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = fn(data[i]);
    }
    return result;
  }

  /// 최솟값
  double minValue() {
    double m = double.infinity;
    for (int i = 0; i < data.length; i++) {
      if (data[i] < m) m = data[i];
    }
    return m;
  }

  /// 최댓값
  double maxValue() {
    double m = double.negativeInfinity;
    for (int i = 0; i < data.length; i++) {
      if (data[i] > m) m = data[i];
    }
    return m;
  }

  /// 합계
  double sum() {
    double s = 0;
    for (int i = 0; i < data.length; i++) {
      s += data[i];
    }
    return s;
  }

  /// np.clip 대체
  Matrix2D clip(double low, double high) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = data[i].clamp(low, high);
    }
    return result;
  }

  /// np.maximum(mat, val) 대체
  Matrix2D clampMin(double minVal) {
    final result = Matrix2D(rows, cols);
    for (int i = 0; i < data.length; i++) {
      result.data[i] = max(data[i], minVal);
    }
    return result;
  }

  /// np.sqrt 요소별
  Matrix2D sqrtElm() {
    return map((v) => sqrt(max(v, 0)));
  }

  /// 0~1 정규화
  Matrix2D normalize01() {
    final mn = minValue();
    final mx = maxValue();
    final range = mx - mn;
    if (range < 1e-8) return Matrix2D.zeros(rows, cols);
    return map((v) => (v - mn) / range);
  }

  /// NaN/Inf를 0으로 변환
  Matrix2D nanToZero() {
    return map((v) => v.isFinite ? v : 0.0);
  }

  /// 특정 값보다 큰 인덱스 목록 [(row, col), ...]
  List<(int, int)> argWhere(bool Function(double) test) {
    final result = <(int, int)>[];
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        if (test(get(r, c))) {
          result.add((r, c));
        }
      }
    }
    return result;
  }

  /// edge 패딩으로 크기를 (targetRows, targetCols)로 확장
  Matrix2D padToShape(int targetRows, int targetCols) {
    if (targetRows <= rows && targetCols <= cols) return copy();
    final result = Matrix2D(targetRows, targetCols);
    for (int r = 0; r < targetRows; r++) {
      final sr = r < rows ? r : rows - 1;
      for (int c = 0; c < targetCols; c++) {
        final sc = c < cols ? c : cols - 1;
        result.set(r, c, get(sr, sc));
      }
    }
    return result;
  }

  /// (targetRows, targetCols) 영역만 잘라냄
  Matrix2D cropToShape(int targetRows, int targetCols) {
    final tr = min(targetRows, rows);
    final tc = min(targetCols, cols);
    final result = Matrix2D(tr, tc);
    for (int r = 0; r < tr; r++) {
      for (int c = 0; c < tc; c++) {
        result.set(r, c, get(r, c));
      }
    }
    return result;
  }

  /// 2D list로 변환
  List<List<double>> toList() {
    return List.generate(rows, (r) {
      return List.generate(cols, (c) => get(r, c));
    });
  }

  /// 1D flat list로 변환
  List<double> toFlatList() => data.toList();
}
