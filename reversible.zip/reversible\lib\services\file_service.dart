import 'dart:io';
import 'package:csv/csv.dart';

/// CSV 파일 파싱 서비스
class FileService {
  /// CSV 파일에서 측정 데이터 파싱
  /// 기대 형식: x, y, z, value (헤더 포함 가능)
  static Future<List<Map<String, double>>> parseCsv(String filePath) async {
    final file = File(filePath);
    final content = await file.readAsString();
    final rows = const CsvToListConverter().convert(content);

    if (rows.isEmpty) return [];

    // 헤더 감지
    int startRow = 0;
    if (rows[0].any((cell) => cell is String && double.tryParse(cell) == null)) {
      startRow = 1;
    }

    final result = <Map<String, double>>[];
    for (int i = startRow; i < rows.length; i++) {
      final row = rows[i];
      if (row.length < 4) continue;
      try {
        result.add({
          'x': _toDouble(row[0]),
          'y': _toDouble(row[1]),
          'z': _toDouble(row[2]),
          'value': _toDouble(row[3]),
        });
      } catch (_) {
        continue;
      }
    }
    return result;
  }

  static double _toDouble(dynamic v) {
    if (v is double) return v;
    if (v is int) return v.toDouble();
    if (v is String) return double.parse(v);
    throw FormatException('Cannot convert $v to double');
  }
}
