import 'dart:math';
import '../core/matrix2d.dart';
import '../core/math_utils.dart';

/// AGL 정규화 계산 (model/outdoor.py의 compute_agl_norm 포팅)
Matrix2D computeAglNorm(
  Matrix2D terrain,
  double altitude, {
  Map<String, double>? coordNorm,
}) {
  if (altitude <= 0) throw ArgumentError('altitude must be > 0');

  final cn = coordNorm ?? {};
  final xyUnit = max((cn['xy_unit'] ?? 1.0), 1e-6);

  final tScaled = terrain.scale(1.0 / xyUnit);
  final altNorm = altitude / xyUnit;

  final agl = tScaled.map((t) => max(altNorm - t, 0.0));
  final aglNorm = agl.scale(1.0 / max(altNorm, 1e-6));

  return aglNorm;
}

/// U-Net 패딩 형태 계산
(int, int) computePaddedShapeForModel(int h, int w, {int factor = 4}) {
  return computePaddedShape(h, w, factor: factor);
}

/// 입력 텐서에 edge 패딩 적용 (4D: 1,H,W,C)
List<List<List<List<double>>>> padInput4D(
  List<List<List<List<double>>>> input,
  int targetH,
  int targetW,
) {
  final h = input[0].length;
  final w = input[0][0].length;

  if (h >= targetH && w >= targetW) return input;

  return [
    List.generate(targetH, (r) {
      final sr = r < h ? r : h - 1;
      return List.generate(targetW, (col) {
        final sc = col < w ? col : w - 1;
        return List<double>.from(input[0][sr][sc]);
      });
    })
  ];
}

/// 출력에서 원래 크기로 crop
Matrix2D cropOutput(Matrix2D prediction, int originalH, int originalW) {
  return prediction.cropToShape(originalH, originalW);
}
