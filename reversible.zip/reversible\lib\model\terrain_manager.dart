import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../core/matrix2d.dart';

class TerrainInfo {
  final String tag;
  final Matrix2D terrain;
  final double extentX;
  final double extentY;
  final double? centerLat;
  final double? centerLon;
  final Map<String, double>? bounds; // {left, right, bottom, top}
  final String? crs;
  final double terrainBaseAltitude;

  TerrainInfo({
    required this.tag,
    required this.terrain,
    required this.extentX,
    required this.extentY,
    this.centerLat,
    this.centerLon,
    this.bounds,
    this.crs,
    this.terrainBaseAltitude = 0.0,
  });
}

/// 지형 데이터 로컬 저장/불러오기
class TerrainManager {
  Future<void> save(
    String tag,
    Matrix2D terrain,
    double extentX,
    double extentY, {
    double? centerLat,
    double? centerLon,
    Map<String, double>? bounds,
    String? crs,
    double terrainBaseAltitude = 0.0,
  }) async {
    final path = await _terrainPath(tag);
    final file = File(path);
    await file.parent.create(recursive: true);
    await file.writeAsString(jsonEncode({
      'tag': tag,
      'z_data': terrain.toList(),
      'extent_x_m': extentX,
      'extent_y_m': extentY,
      if (centerLat != null) 'center_lat': centerLat,
      if (centerLon != null) 'center_lon': centerLon,
      if (bounds != null) 'bounds': bounds,
      if (crs != null) 'crs': crs,
      'terrain_base_altitude_m': terrainBaseAltitude,
    }));
  }

  Future<TerrainInfo?> load(String tag) async {
    final path = await _terrainPath(tag);
    final file = File(path);
    if (!await file.exists()) return null;

    final data = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
    final zList = data['z_data'] as List;
    final rows = zList.length;
    final cols = (zList[0] as List).length;
    final terrain = Matrix2D(rows, cols);
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        terrain.set(r, c, (zList[r][c] as num).toDouble());
      }
    }

    Map<String, double>? bounds;
    if (data['bounds'] != null) {
      bounds = (data['bounds'] as Map).map((k, v) => MapEntry(k as String, (v as num).toDouble()));
    }

    return TerrainInfo(
      tag: tag,
      terrain: terrain,
      extentX: (data['extent_x_m'] as num).toDouble(),
      extentY: (data['extent_y_m'] as num).toDouble(),
      centerLat: data['center_lat'] != null ? (data['center_lat'] as num).toDouble() : null,
      centerLon: data['center_lon'] != null ? (data['center_lon'] as num).toDouble() : null,
      bounds: bounds,
      crs: data['crs'] as String?,
      terrainBaseAltitude: data['terrain_base_altitude_m'] != null
          ? (data['terrain_base_altitude_m'] as num).toDouble()
          : 0.0,
    );
  }

  Future<List<String>> listAll() async {
    final dir = await _terrainDir();
    if (!await dir.exists()) return [];
    return dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.endsWith('.json'))
        .map((f) => f.path.split(Platform.pathSeparator).last.replaceAll('.json', ''))
        .toList()
      ..sort();
  }

  Future<void> delete(String tag) async {
    final path = await _terrainPath(tag);
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  Future<Directory> _terrainDir() async {
    final base = await getApplicationSupportDirectory();
    return Directory('${base.path}/terrains');
  }

  Future<String> _terrainPath(String tag) async {
    final dir = await _terrainDir();
    return '${dir.path}/$tag.json';
  }
}
