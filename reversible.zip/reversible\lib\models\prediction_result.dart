import '../core/matrix2d.dart';

class PredictionResult {
  final Matrix2D prediction;
  final String modelName;
  final Duration elapsed;

  PredictionResult({
    required this.prediction,
    required this.modelName,
    required this.elapsed,
  });
}
