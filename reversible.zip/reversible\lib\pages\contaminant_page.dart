import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/terrain_provider.dart';
import '../providers/contamination_provider.dart';
import '../models/contamination_data.dart';
import '../core/matrix2d.dart';
import '../core/math_utils.dart';
import '../simulation/outdoor_simulation.dart';
import '../widgets/plotly_webview.dart';
import '../widgets/plotly_chart_builder.dart';

class ContaminantPage extends ConsumerStatefulWidget {
  const ContaminantPage({super.key});

  @override
  ConsumerState<ContaminantPage> createState() => _ContaminantPageState();
}

class _ContaminantPageState extends ConsumerState<ContaminantPage> {
  @override
  Widget build(BuildContext context) {
    final terrain = ref.watch(terrainProvider).terrain;
    final contState = ref.watch(contaminationProvider);
    final contamination = contState.contamination;

    if (terrain == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('2. 오염원 배치')),
        body: const Center(child: Text('먼저 지형을 생성해주세요.')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('2. 오염원 배치')),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // 왼쪽: 컨트롤 패널
          SizedBox(
            width: 280,
            child: Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '오염원 설정',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '랜덤 배치 기능을 사용해 오염원을 추가하세요.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.red.shade700,
                      ),
                      onPressed: () => _addRandomSources(terrain),
                      icon: const Icon(Icons.add_location),
                      label: const Text('랜덤 오염원 배치'),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton(
                      onPressed: () {
                        ref.read(contaminationProvider.notifier).clear();
                      },
                      child: const Text('초기화'),
                    ),
                    const Spacer(),
                    if (contamination != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.blue.withValues(alpha: 0.1),
                          border: Border.all(color: Colors.blue.withValues(alpha: 0.3)),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '오염원 ${contamination.sources.length}개 배치됨',
                          style: const TextStyle(fontSize: 12, color: Colors.blue),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),

          // 오른쪽: 맵
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0, 12, 12, 12),
              child: Card(
                child: PlotlyWebView(
                  height: double.infinity,
                  chartSpec: PlotlyChartBuilder.terrainWithContamination(
                    terrain.elevation,
                    contamination?.contaminationMap ?? Matrix2D.zeros(terrain.rows, terrain.cols),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _addRandomSources(dynamic terrain) {
    final t = terrain as dynamic;
    final rows = t.rows as int;
    final cols = t.cols as int;

    final rng = Random();
    final count = 1 + rng.nextInt(20);

    Matrix2D currentMap = Matrix2D.zeros(rows, cols);
    final newSources = <ContaminationSource>[];

    for (int i = 0; i < count; i++) {
      final posY = randInt(5, rows - 5);
      final posX = randInt(5, cols - 5);
      final strength = 50.0 + rng.nextDouble() * 150.0;
      final sigma = 3.0 + rng.nextDouble() * 5.0;

      currentMap = addGaussianSource(
        currentMap,
        posY,
        posX,
        strength: strength,
        sigma: sigma,
      );

      newSources.add(ContaminationSource(
        row: posY,
        col: posX,
        strength: strength,
        sigma: sigma,
      ));
    }

    ref.read(contaminationProvider.notifier).setContamination(
      ContaminationData(
        contaminationMap: currentMap,
        sources: newSources,
      ),
    );
  }
}
