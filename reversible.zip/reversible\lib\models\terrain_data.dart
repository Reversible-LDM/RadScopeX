import '../core/matrix2d.dart';

class TerrainData {
  final Matrix2D elevation;
  final String type; // flat, hill, puddle, indoor
  final String label;

  TerrainData({
    required this.elevation,
    required this.type,
    required this.label,
  });

  int get rows => elevation.rows;
  int get cols => elevation.cols;
}
