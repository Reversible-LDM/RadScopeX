import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'pages/terrain_page.dart';
import 'pages/contaminant_page.dart';
import 'pages/simulation_page.dart';
import 'pages/training_page.dart';
import 'pages/field_page.dart';
import 'providers/server_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: ReversibleApp()));
}

class ReversibleApp extends StatelessWidget {
  const ReversibleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ReversibleAI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _currentIndex = 0;

  static const _pages = <Widget>[
    TerrainPage(),
    ContaminantPage(),
    SimulationPage(),
    TrainingPage(),
    FieldPage(),
  ];

  @override
  Widget build(BuildContext context) {
    final online = ref.watch(serverOnlineProvider);
    final isOnline = online.valueOrNull ?? false;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 32,
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Row(
              children: [
                Icon(isOnline ? Icons.wifi : Icons.wifi_off,
                    size: 14,
                    color: isOnline ? Colors.greenAccent : Colors.grey),
                const SizedBox(width: 4),
                Text(isOnline ? '온라인' : '오프라인',
                    style: TextStyle(
                        fontSize: 11,
                        color: isOnline ? Colors.greenAccent : Colors.grey)),
              ],
            ),
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.terrain),
            label: '지형',
          ),
          NavigationDestination(
            icon: Icon(Icons.warning_amber),
            label: '오염원',
          ),
          NavigationDestination(
            icon: Icon(Icons.flight),
            label: '시뮬레이션',
          ),
          NavigationDestination(
            icon: Icon(Icons.psychology),
            label: 'AI',
          ),
          NavigationDestination(
            icon: Icon(Icons.analytics),
            label: '필드',
          ),
        ],
      ),
    );
  }
}
