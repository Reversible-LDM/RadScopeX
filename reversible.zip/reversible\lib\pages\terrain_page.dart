import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import '../core/matrix2d.dart';
import '../models/terrain_data.dart';
import '../providers/terrain_provider.dart';
import '../services/training_service.dart';
import '../widgets/plotly_webview.dart';
import '../widgets/plotly_chart_builder.dart';

class TerrainPage extends ConsumerStatefulWidget {
  const TerrainPage({super.key});

  @override
  ConsumerState<TerrainPage> createState() => _TerrainPageState();
}

class _TerrainPageState extends ConsumerState<TerrainPage> {
  String _selectedType = 'flat';
  int _xSize = 100;
  int _ySize = 100;
  String? _uploadError;
  bool _isUploading = false;
  bool _isOnline = false;
  final _trainingService = TrainingService();

  @override
  void initState() {
    super.initState();
    _trainingService.checkConnection().then((v) {
      if (mounted) setState(() => _isOnline = v);
    });
  }

  Future<void> _uploadDem() async {
    setState(() { _uploadError = null; _isUploading = true; });
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['tif', 'tiff'],
        withData: true,
      );
      if (result == null || result.files.single.bytes == null) return;

      final file = result.files.single;
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('${_trainingService.serverUrl}/api/generate_terrain'),
      );
      request.fields['terrain_type'] = 'dem_upload';
      request.files.add(http.MultipartFile.fromBytes(
        'dem_file',
        file.bytes!,
        filename: file.name,
      ));

      final streamed = await request.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      if (streamed.statusCode != 200) {
        final err = jsonDecode(body)['error'] ?? body;
        throw Exception(err);
      }

      final data = jsonDecode(body) as Map<String, dynamic>;
      final zList = (data['z_data'] as List)
          .map((row) => (row as List).map((v) => (v as num).toDouble()).toList())
          .toList();
      final elevation = Matrix2D.fromList(zList);
      final name = file.name.replaceAll(RegExp(r'\.(tif|tiff)$', caseSensitive: false), '');
      ref.read(terrainProvider.notifier).setTerrain(TerrainData(
            elevation: elevation,
            type: 'dem',
            label: name,
          ));
    } catch (e) {
      setState(() => _uploadError = 'DEM 업로드 오류: $e');
    } finally {
      setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final terrain = ref.watch(terrainProvider).terrain;

    return Scaffold(
      appBar: AppBar(title: const Text('1. 지형 선택')),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 700;
          if (isWide) {
            return _buildWideLayout(terrain);
          }
          return _buildNarrowLayout(terrain);
        },
      ),
    );
  }

  /// 좁은 화면 (폰): 세로 스크롤
  Widget _buildNarrowLayout(TerrainData? terrain) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildControlCards(terrain),
          if (terrain != null) ...[
            const SizedBox(height: 16),
            SizedBox(
              height: 400,
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Text('${terrain.label} (${terrain.rows}×${terrain.cols})',
                          style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Expanded(
                        child: PlotlyWebView(
                          chartSpec: PlotlyChartBuilder.terrainWhite(terrain.elevation),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  /// 넓은 화면 (태블릿): 좌우 레이아웃
  Widget _buildWideLayout(TerrainData? terrain) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 450,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [_buildControlCards(terrain)],
            ),
          ),
        ),
        Expanded(
          child: terrain == null
              ? const Center(child: Text('지형을 생성하거나 업로드하세요'))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        children: [
                          Text('${terrain.label} (${terrain.rows}×${terrain.cols})',
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 8),
                          Expanded(
                            child: PlotlyWebView(
                              chartSpec: PlotlyChartBuilder.terrainWhite(terrain.elevation),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
        ),
      ],
    );
  }

  /// 지형 생성 + DEM 업로드 + 현재 지형 정보 카드
  Widget _buildControlCards(TerrainData? terrain) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // 지형 생성
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('지형 생성',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'flat', label: Text('평지')),
                    ButtonSegment(value: 'hill', label: Text('언덕')),
                    ButtonSegment(value: 'puddle', label: Text('웅덩이')),
                    ButtonSegment(value: 'indoor', label: Text('실내')),
                  ],
                  selected: {_selectedType},
                  onSelectionChanged: (set) =>
                      setState(() => _selectedType = set.first),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          labelText: '가로 (X)',
                          border: OutlineInputBorder(),
                        ),
                        keyboardType: TextInputType.number,
                        controller: TextEditingController(text: '$_xSize'),
                        onChanged: (v) => _xSize = int.tryParse(v) ?? _xSize,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        decoration: const InputDecoration(
                          labelText: '세로 (Y)',
                          border: OutlineInputBorder(),
                        ),
                        keyboardType: TextInputType.number,
                        controller: TextEditingController(text: '$_ySize'),
                        onChanged: (v) => _ySize = int.tryParse(v) ?? _ySize,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () {
                    ref.read(terrainProvider.notifier)
                      ..setSize(_xSize, _ySize)
                      ..setType(_selectedType)
                      ..generate();
                  },
                  icon: const Icon(Icons.terrain),
                  label: const Text('지형 생성'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // DEM 업로드
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('DEM 업로드 (TIF)',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(
                  _isOnline
                      ? 'GeoTIFF (.tif / .tiff) 파일'
                      : 'GeoTIFF (.tif / .tiff) 파일\n⚠ 서버 오프라인',
                  style: TextStyle(
                      fontSize: 12,
                      color: _isOnline ? Colors.grey : Colors.orange),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: (_isUploading || !_isOnline) ? null : _uploadDem,
                  icon: _isUploading
                      ? const SizedBox(
                          width: 16, height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.upload_file),
                  label: Text(_isUploading ? '업로드 중...' : 'TIF 파일 선택'),
                ),
                if (_uploadError != null) ...[
                  const SizedBox(height: 8),
                  Text(_uploadError!,
                      style: const TextStyle(
                          color: Colors.redAccent, fontSize: 12)),
                ],
              ],
            ),
          ),
        ),

        // 현재 지형 정보
        if (terrain != null) ...[
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('현재 지형',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('이름: ${terrain.label}'),
                  Text('크기: ${terrain.rows} × ${terrain.cols}'),
                  Text('유형: ${terrain.type}'),
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }
}
