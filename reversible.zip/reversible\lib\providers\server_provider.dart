import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../services/training_service.dart';

final _service = TrainingService();

final serverUrlProvider = StateProvider<String>((ref) => _service.serverUrl);

final serverOnlineProvider = StreamProvider.autoDispose<bool>((ref) async* {
  final url = ref.watch(serverUrlProvider);
  _service.setServerUrl(url);

  yield await _service.checkConnection();

  await for (final result in Connectivity().onConnectivityChanged) {
    final hasNetwork = result.any((r) =>
        r == ConnectivityResult.wifi ||
        r == ConnectivityResult.mobile ||
        r == ConnectivityResult.ethernet);
    if (hasNetwork) {
      yield await _service.checkConnection();
    } else {
      yield false;
    }
  }
});
