import 'dart:math';
import 'matrix2d.dart';

/// np.linspace 대체
List<double> linspace(double start, double end, int num) {
  if (num <= 0) return [];
  if (num == 1) return [start];
  final step = (end - start) / (num - 1);
  return List.generate(num, (i) => start + i * step);
}

/// np.arange 대체
List<int> arange(int start, int end) {
  return List.generate(end - start, (i) => start + i);
}

/// np.meshgrid 대체 - (xx, yy) 반환
(Matrix2D, Matrix2D) meshgrid(List<double> x, List<double> y) {
  final rows = y.length;
  final cols = x.length;
  final xx = Matrix2D(rows, cols);
  final yy = Matrix2D(rows, cols);
  for (int r = 0; r < rows; r++) {
    for (int c = 0; c < cols; c++) {
      xx.set(r, c, x[c]);
      yy.set(r, c, y[r]);
    }
  }
  return (xx, yy);
}

/// np.gradient 대체 (2D, axis=0 과 axis=1)
/// 반환: (gradY, gradX) - 중앙차분 사용
(Matrix2D, Matrix2D) gradient2D(Matrix2D mat, double dy, double dx) {
  final rows = mat.rows;
  final cols = mat.cols;
  final gradY = Matrix2D(rows, cols);
  final gradX = Matrix2D(rows, cols);

  // Y 방향 gradient (axis=0)
  for (int c = 0; c < cols; c++) {
    // 첫 행: forward
    gradY.set(0, c, (mat.get(1, c) - mat.get(0, c)) / dy);
    // 중간 행: central
    for (int r = 1; r < rows - 1; r++) {
      gradY.set(r, c, (mat.get(r + 1, c) - mat.get(r - 1, c)) / (2 * dy));
    }
    // 마지막 행: backward
    if (rows > 1) {
      gradY.set(
          rows - 1, c, (mat.get(rows - 1, c) - mat.get(rows - 2, c)) / dy);
    }
  }

  // X 방향 gradient (axis=1)
  for (int r = 0; r < rows; r++) {
    // 첫 열: forward
    gradX.set(r, 0, (mat.get(r, 1) - mat.get(r, 0)) / dx);
    // 중간 열: central
    for (int c = 1; c < cols - 1; c++) {
      gradX.set(r, c, (mat.get(r, c + 1) - mat.get(r, c - 1)) / (2 * dx));
    }
    // 마지막 열: backward
    if (cols > 1) {
      gradX.set(
          r, cols - 1, (mat.get(r, cols - 1) - mat.get(r, cols - 2)) / dx);
    }
  }

  return (gradY, gradX);
}

/// 3D 벡터의 유클리드 노름
double norm3(double x, double y, double z) {
  return sqrt(x * x + y * y + z * z);
}

/// 3D 벡터 내적
double dot3(double x1, double y1, double z1, double x2, double y2, double z2) {
  return x1 * x2 + y1 * y2 + z1 * z2;
}

/// U-Net padding 계산 (factor의 배수로 올림)
(int, int) computePaddedShape(int h, int w, {int factor = 4}) {
  int newH = ((h + factor - 1) ~/ factor) * factor;
  int newW = ((w + factor - 1) ~/ factor) * factor;
  return (max(1, newH), max(1, newW));
}

/// 난수 생성기
final _rng = Random();

/// Python np.random.randint 대체
int randInt(int low, int high) {
  return low + _rng.nextInt(high - low);
}

/// Python np.random.uniform 대체
double randUniform(double low, double high) {
  return low + _rng.nextDouble() * (high - low);
}
