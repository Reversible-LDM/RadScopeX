import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/prediction_result.dart';
import '../core/matrix2d.dart';

class PredictionState {
  final PredictionResult? result;
  final Matrix2D? idwResult;
  final bool isRunning;
  final String? error;

  PredictionState({
    this.result,
    this.idwResult,
    this.isRunning = false,
    this.error,
  });

  PredictionState copyWith({
    PredictionResult? result,
    Matrix2D? idwResult,
    bool? isRunning,
    String? error,
  }) {
    return PredictionState(
      result: result ?? this.result,
      idwResult: idwResult ?? this.idwResult,
      isRunning: isRunning ?? this.isRunning,
      error: error,
    );
  }
}

class PredictionNotifier extends StateNotifier<PredictionState> {
  PredictionNotifier() : super(PredictionState());

  void setResult(PredictionResult result) {
    state = state.copyWith(result: result, isRunning: false, error: null);
  }

  void setIdwResult(Matrix2D idw) {
    state = state.copyWith(idwResult: idw, isRunning: false);
  }

  void setRunning(bool running) {
    state = state.copyWith(isRunning: running, error: null);
  }

  void setError(String err) {
    state = state.copyWith(isRunning: false, error: err);
  }

  void clear() {
    state = PredictionState();
  }
}

final predictionProvider =
    StateNotifierProvider<PredictionNotifier, PredictionState>((ref) {
  return PredictionNotifier();
});
