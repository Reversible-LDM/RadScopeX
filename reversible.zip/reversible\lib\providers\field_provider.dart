import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/matrix2d.dart';

class FieldState {
  final Matrix2D? terrain;
  final String? modelTag;
  final String? csvFileName;

  FieldState({this.terrain, this.modelTag, this.csvFileName});

  FieldState copyWith({
    Matrix2D? terrain,
    String? modelTag,
    String? csvFileName,
  }) {
    return FieldState(
      terrain: terrain ?? this.terrain,
      modelTag: modelTag ?? this.modelTag,
      csvFileName: csvFileName ?? this.csvFileName,
    );
  }
}

class FieldNotifier extends StateNotifier<FieldState> {
  FieldNotifier() : super(FieldState());

  void setResult({
    required Matrix2D terrain,
    required String modelTag,
    required String csvFileName,
  }) {
    state = state.copyWith(
      terrain: terrain,
      modelTag: modelTag,
      csvFileName: csvFileName,
    );
  }

  void clear() {
    state = FieldState();
  }
}

final fieldProvider =
    StateNotifierProvider<FieldNotifier, FieldState>((ref) => FieldNotifier());
