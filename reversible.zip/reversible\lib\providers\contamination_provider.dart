import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/contamination_data.dart';

class ContaminationState {
  final ContaminationData? contamination;

  ContaminationState({this.contamination});

  ContaminationState copyWith({ContaminationData? contamination}) {
    return ContaminationState(
      contamination: contamination ?? this.contamination,
    );
  }
}

class ContaminationNotifier extends StateNotifier<ContaminationState> {
  ContaminationNotifier() : super(ContaminationState());

  void setContamination(ContaminationData data) {
    state = state.copyWith(contamination: data);
  }

  void clear() {
    state = ContaminationState();
  }
}

final contaminationProvider =
    StateNotifierProvider<ContaminationNotifier, ContaminationState>((ref) {
  return ContaminationNotifier();
});
