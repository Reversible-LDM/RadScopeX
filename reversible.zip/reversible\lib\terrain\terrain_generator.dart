import 'dart:math';
import '../core/matrix2d.dart';

/// Python terrain_generator.create_terrain() 포팅
Matrix2D createTerrain(int xSize, int ySize, String terrainType) {
  final z = Matrix2D.zeros(ySize, xSize);

  if (terrainType == 'flat') {
    return z;
  }

  if (terrainType == 'puddle') {
    final centerX = xSize ~/ 2;
    final centerY = ySize ~/ 2;
    final radius = min(xSize, ySize) / 4;
    final r2 = 2 * radius * radius;

    for (int r = 0; r < ySize; r++) {
      for (int c = 0; c < xSize; c++) {
        final dx = (c - centerX).toDouble();
        final dy = (r - centerY).toDouble();
        final dist2 = dx * dx + dy * dy;
        z.set(r, c, 10 * (1 - exp(-dist2 / r2)));
      }
    }
    return z;
  }

  if (terrainType == 'hill') {
    final centerX = xSize ~/ 2;
    final centerY = ySize ~/ 2;
    final radius = min(xSize, ySize) / 3;
    final r2 = 2 * radius * radius;

    for (int r = 0; r < ySize; r++) {
      for (int c = 0; c < xSize; c++) {
        final dx = (c - centerX).toDouble();
        final dy = (r - centerY).toDouble();
        final dist2 = dx * dx + dy * dy;
        z.set(r, c, 20 * exp(-dist2 / r2));
      }
    }
    return z;
  }

  // 알 수 없는 타입이면 flat
  return z;
}
