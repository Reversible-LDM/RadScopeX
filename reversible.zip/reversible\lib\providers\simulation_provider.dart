import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/drone_measurement.dart';

class SimulationState {
  final DroneMeasurement? measurement;
  final double altitude;
  final int numLines;
  final bool isRunning;

  SimulationState({
    this.measurement,
    this.altitude = 30.0,
    this.numLines = 20,
    this.isRunning = false,
  });

  SimulationState copyWith({
    DroneMeasurement? measurement,
    double? altitude,
    int? numLines,
    bool? isRunning,
  }) {
    return SimulationState(
      measurement: measurement ?? this.measurement,
      altitude: altitude ?? this.altitude,
      numLines: numLines ?? this.numLines,
      isRunning: isRunning ?? this.isRunning,
    );
  }
}

class SimulationNotifier extends StateNotifier<SimulationState> {
  SimulationNotifier() : super(SimulationState());

  void setAltitude(double alt) {
    state = state.copyWith(altitude: alt);
  }

  void setNumLines(int n) {
    state = state.copyWith(numLines: n);
  }

  void setRunning(bool running) {
    state = state.copyWith(isRunning: running);
  }

  void setMeasurement(DroneMeasurement m) {
    state = state.copyWith(measurement: m, isRunning: false);
  }

  void clear() {
    state = SimulationState(
      altitude: state.altitude,
      numLines: state.numLines,
    );
  }
}

final simulationProvider =
    StateNotifierProvider<SimulationNotifier, SimulationState>((ref) {
  return SimulationNotifier();
});
