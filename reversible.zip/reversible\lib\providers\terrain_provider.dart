import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/terrain_data.dart';
import '../terrain/terrain_generator.dart';

class TerrainState {
  final TerrainData? terrain;
  final int xSize;
  final int ySize;
  final String terrainType;

  TerrainState({
    this.terrain,
    this.xSize = 100,
    this.ySize = 100,
    this.terrainType = 'flat',
  });

  TerrainState copyWith({
    TerrainData? terrain,
    int? xSize,
    int? ySize,
    String? terrainType,
  }) {
    return TerrainState(
      terrain: terrain ?? this.terrain,
      xSize: xSize ?? this.xSize,
      ySize: ySize ?? this.ySize,
      terrainType: terrainType ?? this.terrainType,
    );
  }
}

class TerrainNotifier extends StateNotifier<TerrainState> {
  TerrainNotifier() : super(TerrainState());

  void setSize(int x, int y) {
    state = state.copyWith(xSize: x, ySize: y);
  }

  void setType(String type) {
    state = state.copyWith(terrainType: type);
  }

  void generate() {
    final elevation = createTerrain(
      state.xSize,
      state.ySize,
      state.terrainType,
    );
    state = state.copyWith(
      terrain: TerrainData(
        elevation: elevation,
        type: state.terrainType,
        label: '${state.terrainType} ${state.xSize}x${state.ySize}',
      ),
    );
  }

  void setTerrain(TerrainData data) {
    state = state.copyWith(
      terrain: data,
      xSize: data.cols,
      ySize: data.rows,
      terrainType: data.type,
    );
  }
}

final terrainProvider =
    StateNotifierProvider<TerrainNotifier, TerrainState>((ref) {
  return TerrainNotifier();
});
